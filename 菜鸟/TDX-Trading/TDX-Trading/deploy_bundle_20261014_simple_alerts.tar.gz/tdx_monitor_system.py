#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通达信多模型实时监控系统  (门面入口)
====================================
2026-08-19 包化重构：原 3123 行单文件按职责拆分为 monitor/ 包。
本文件只保留 main() 入口和向后兼容 re-export，
systemd tdx.service 直接跑本文件，无需改动。

新结构（详见 monitor/__init__.py）:
    monitor/config.py     配置加载/持久化/迁移 + DEFAULT_CONFIG
    monitor/common.py     常量 + fmt_price/market_of 等基础工具
    monitor/cond_utils.py 条件单工具函数（纯函数）
    monitor/engine.py     MonitorSystem：QMT 同步/行情轮询/模型分发
    monitor/models/       监控模型插件（每模型一个文件，REGISTRY 注册）
    monitor/server.py     HTTP Handler + 定时调度线程
    monitor/ui.py         读取 templates/index.html 前端页面

用法:
    python tdx_monitor_system.py
    浏览器打开 http://localhost:8088
"""

import logging
import threading

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s [%(levelname)s] %(message)s')

import minute_collector as mc
import stock_data_cache as _sdc
import stock_news_collector as snc

from monitor import config as _config
from monitor.common import (QMT_BASE_URL, QMT_GET_STOCKS, QMT_REPORT_SIGNAL,   # noqa: F401
                            QMT_SYNC_INTERVAL, QMT_TIMEOUT, WEB_REFRESH_MS,    # noqa: F401
                            HOST, PORT,                                        # noqa: F401
                            QMT_MARKET_MAP, TDX_MARKET_TO_QMT,                 # noqa: F401
                            fmt_price, market_of, rec_yclose,                  # noqa: F401
                            metric_label_of, rises_on)                         # noqa: F401
from monitor.cond_utils import (COND_LABELS, COND_LABELS2, BUY_LABELS,         # noqa: F401
                                cond_price, cond_window_ok,                    # noqa: F401
                                cond_trigger_desc, cond_kinds_of,              # noqa: F401
                                _parse_qmt_time, _parse_qmt_date,              # noqa: F401
                                _cond_window_txt)                              # noqa: F401
from monitor.config import (DEFAULT_CONFIG, load_config, save_config,          # noqa: F401
                            default_models_for_side, CONFIG_FILE)              # noqa: F401
from monitor.engine import MonitorSystem
from monitor.models import REGISTRY                                           # noqa: F401
from monitor.models.cond_model import _eval_cond_trigger                      # noqa: F401
from monitor.ui import HTML                                                   # noqa: F401
import monitor.server as _server

# ---- 向后兼容 re-export（test_cond_order.py 等历史引用走这里）----
CACHE = _sdc.CACHE

# 模块级单例（保持与原文件相同的加载语义：import 即建实例）
SYS = MonitorSystem()
_server.SYS = SYS


def main():
    t = threading.Thread(target=SYS.run, daemon=True)
    t.start()
    # 启动分钟线采集（daemon 线程，交易时段每分钟自动采集全市场）
    mc.start()
    # 启动股票资讯采集（3个daemon线程：公告/个股新闻/研报）
    snc.COLLECTOR.start()
    # 启动每日17:00定时增量更新（仅交易日）
    threading.Thread(target=_server._daily_update_scheduler, daemon=True, name='DailyUpdate').start()
    logging.info('⏰ 每日17:00定时增量更新已启用（仅交易日）')
    # 启动盘中板块分钟线实时刷新（交易日 9:30-15:05 每 5 分钟）
    threading.Thread(target=_server._sector_realtime_scheduler, daemon=True,
                     name='SectorRealtime').start()
    logging.info('📊 盘中板块分钟线实时刷新已启用（每5分钟）')
    from http.server import ThreadingHTTPServer
    srv = ThreadingHTTPServer((HOST, PORT), _server.Handler)
    logging.info('✅ 多模型监控系统已启动，浏览器打开: http://localhost:%d', PORT)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        SYS.running = False
        srv.shutdown()


if __name__ == '__main__':
    main()
