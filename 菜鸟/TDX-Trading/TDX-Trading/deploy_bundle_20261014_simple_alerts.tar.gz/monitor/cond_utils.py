# -*- coding: utf-8 -*-
"""条件单工具函数（纯函数，无状态，可独立单测）。

从原 tdx_monitor_system.py 的「工具函数」区整体迁出，行为不变。
"""

import datetime as dt
import re


def cond_price(v):
    """条件单价格归一化：None / 0 / 非法值 一律视为「未设置」。"""
    if v is None:
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if f > 0 else None


def _parse_qmt_time(v):
    """解析后端下发的时间字段（LocalDateTime 序列化多为 'yyyy-MM-dd HH:mm:ss'，
    也兼容 ISO-8601 带毫秒/时区、epoch 毫秒/秒数字）。失败返回 None（=无窗口约束）。"""
    if not v:
        return None
    if isinstance(v, (int, float)):
        f = float(v)
        # fromtimestamp 收秒；后端序列化为毫秒（2026 年毫秒≈1.77e12 > 1e12 视为毫秒）
        if f >= 1e12:
            f /= 1000
        try:
            return dt.datetime.fromtimestamp(f)
        except (ValueError, OSError, OverflowError):
            return None
    s = str(v).strip().replace('T', ' ')
    if not s or s == '0':
        return None
    # 去掉毫秒与秒级时区后缀（如 .123 / +08:00 / Z）
    s = re.split(r'[.+\-]\d\d:?\d\d$|Z$|\.\d+', s)[0].strip()
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d'):
        try:
            return dt.datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def _parse_qmt_date(v):
    """解析后端下发的日期字段（expireDate）。

    兼容三种形态：
    - 'yyyy-MM-dd' 字符串（服务端 @JsonFormat 规范格式）
    - epoch 毫秒数字
    - [2026, 8, 21] 数组（Jackson LocalDate 默认序列化，历史形态）
    """
    if isinstance(v, (list, tuple)) and len(v) >= 3:
        try:
            return dt.date(int(v[0]), int(v[1]), int(v[2]))
        except (ValueError, TypeError):
            return None
    t = _parse_qmt_time(v)
    return t.date() if t else None


def cond_window_ok(co, now=None):
    """条件单时间窗校验：afterTime <= now <= beforeTime，且 expireDate 未过期。
    任一字段缺失视为无该约束。"""
    now = now or dt.datetime.now()
    if co.get('after_time') and now < co['after_time']:
        return False
    if co.get('before_time') and now > co['before_time']:
        return False
    ed = co.get('_expire_dt')
    if ed is None and co.get('expire_date'):
        ed = _parse_qmt_date(co['expire_date'])
    return not (ed and now.date() > ed)


def cond_trigger_desc(co):
    """条件单触发条件的人类可读摘要（UI/日志用）。
    比例字段后端存小数（0.03=3%），若历史数据直接存了 3（百分数值）也能容错。
    比例语义 = 当日涨跌幅（锚点=昨收价），无基准价概念。"""
    if co.get('breakout_price') is not None:
        return f"现价≥{co['breakout_price']:.2f} 突破"
    if co.get('breakdown_price') is not None:
        return f"现价≤{co['breakdown_price']:.2f} 跌破"
    for key, sign in (('breakout_ratio', '+'), ('breakdown_ratio', '-')):
        r = cond_price(co.get(key))
        if r is None:
            continue
        pct = r * 100   # 后端存储为小数（0.03=3%），前端提交已 /100
        return f"当日{sign}{pct:.1f}%"
    return '无条件'


def cond_kinds_of(co):
    """条件单包含的触发类型集合（价格4选1，非空即类型）。"""
    kinds = []
    if co.get('breakout_price') is not None:
        kinds.append('breakout_price')
    if co.get('breakdown_price') is not None:
        kinds.append('breakdown_price')
    if co.get('breakout_ratio') is not None:
        kinds.append('breakout_ratio')
    if co.get('breakdown_ratio') is not None:
        kinds.append('breakdown_ratio')
    return kinds


# 条件单触发类型 -> 上报/推送用的信号名（2026-08-19 独立条件单 8 种组合）
COND_LABELS2 = {
    'breakout_price': '突破价格', 'breakdown_price': '跌破价格',
    'breakout_ratio': '突破比例', 'breakdown_ratio': '跌破比例',
}
# 旧标签（股票属性式条件单，已废弃，仅为兼容历史预警记录展示保留）
COND_LABELS = {'stop_loss': '卖出止损', 'take_profit': '卖出止盈'}
BUY_LABELS = {'breakout_buy': '突破买入', 'breakdown_buy': '跌破买入'}


def _cond_window_txt(co):
    """条件单时间窗的可读文本（UI 用）。"""
    parts = []
    if co.get('after_time'):
        parts.append(co['after_time'].strftime('%m-%d %H:%M') + ' 后')
    if co.get('before_time'):
        parts.append(co['before_time'].strftime('%m-%d %H:%M') + ' 前')
    if co.get('valid_trade_days'):
        parts.append(f"{co['valid_trade_days']}个交易日内")
    if co.get('expire_date'):
        parts.append('至 ' + str(co['expire_date']))
    return ' / '.join(parts) if parts else '—'
