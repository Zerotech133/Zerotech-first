# -*- coding: utf-8 -*-
"""通达信多模型监控系统 —— 包化重构版。

原单文件 tdx_monitor_system.py（3123 行）按职责拆分为：

  config.py     配置加载/持久化/迁移 + DEFAULT_CONFIG（4 个内置模型定义）
  cond_utils.py 条件单工具函数（价格归一化/时间窗/触发描述）
  engine.py     MonitorSystem：QMT 同步、行情轮询、模型分发、状态/分组 API
  models/       监控模型插件（每模型一个文件，BaseModel + REGISTRY）
  server.py     HTTP Handler（路由层）
  ui.py         读取 templates/index.html 前端页面

入口仍是 tdx_monitor_system.py（门面，向后兼容 re-export），
systemd tdx.service 无需改动。
"""
