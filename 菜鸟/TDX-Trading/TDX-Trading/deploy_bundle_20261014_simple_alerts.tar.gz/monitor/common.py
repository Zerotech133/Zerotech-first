# -*- coding: utf-8 -*-
"""共享常量与基础工具（fmt_price/market_of/昨收取值/QMT 市场映射）。"""

import os


# ===================== 服务配置 =====================
PORT = 8088
HOST = '0.0.0.0'
WEB_REFRESH_MS = 1500           # 前端自动刷新间隔（毫秒）

# ---- QMT 接口配置 ----
QMT_BASE_URL = os.environ.get('QMT_BASE_URL', 'http://192.168.203.48')
QMT_GET_STOCKS = QMT_BASE_URL + '/app-api/stock/monitor/getMonitorStocks'
QMT_REPORT_SIGNAL = QMT_BASE_URL + '/app-api/stock/monitor/reportSignal'
QMT_SYNC_INTERVAL = 60          # QMT 股票同步间隔（秒）
QMT_TIMEOUT = 8                 # QMT 接口超时（秒）

# 市场代码映射 QMT(t) -> tdx(market_of)
QMT_MARKET_MAP = {'SZ': 0, 'SH': 1, 'BJ': 2}
TDX_MARKET_TO_QMT = {0: 'SZ', 1: 'SH', 2: 'BJ'}


def fmt_price(v):
    """消除浮点精度尾巴，四舍五入到 2 位；非数字原样返回。"""
    if isinstance(v, (int, float)):
        return round(float(v), 2)
    return v


def market_of(code):
    """代码 -> 通达信市场号：6=沪(1)，0/3=深(0)，8/4=北(2)。"""
    c = str(code)
    if c.startswith('6'):
        return 1
    if c.startswith(('0', '3')):
        return 0
    if c.startswith(('8', '4')):
        return 2
    return 1


def rec_yclose(rec):
    """从快照记录取昨收（last_close/yclose/pre_close）。"""
    if isinstance(rec, dict):
        for k in ('last_close', 'yclose', 'pre_close'):
            v = rec.get(k)
            if isinstance(v, (int, float)) and v > 0:
                return float(v)
    else:
        for k in ('last_close', 'yclose', 'pre_close'):
            v = getattr(rec, k, None)
            if isinstance(v, (int, float)) and v > 0:
                return float(v)
    return None


def metric_label_of(mtype):
    if mtype == 'drop':
        return '跌幅'
    if mtype == 'condition':
        return '条件价'
    if mtype == 'buy_condition':
        return '买入条件价'
    return '涨幅'


def rises_on(mtype):
    """该模型检测的是「上涨」还是「下跌」。

    注意：涨跌方向只由 type 决定，与 side（买/卖）无关。
    side 表示触发后的交易语义：涨幅达标→卖出止盈，跌幅达标→买入抄底。
    """
    return mtype != 'drop'
