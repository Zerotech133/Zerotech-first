# -*- coding: utf-8 -*-
"""监控模型插件基类与注册表。

每个监控模型是一个插件类，实现 compute() / summary() / param_text()。
MonitorSystem 通过 REGISTRY 按 model['type'] 分发，新增模型只需：
  1. monitor/models/ 下新建文件，继承 BaseModel 并实现接口
  2. REGISTRY 注册 type
  3. monitor/config.py DEFAULT_CONFIG 加模型种子
"""

# type -> 插件类
REGISTRY = {}


def register(type_name):
    """类装饰器：注册监控模型插件。"""
    def deco(cls):
        REGISTRY[type_name] = cls
        return cls
    return deco


class BaseModel:
    """监控模型插件接口。

    子类实现 compute()；summary()/param_text() 可选覆写。
    所有插件接收 sys（MonitorSystem 实例）作为第一个参数——
    保持与原单文件版相同的数据访问面（qmt_conditions/model_states/…），
    行为不变，只是物理拆分。
    """

    def compute(self, sys, model, now, trading, current):
        """执行一轮判定。model = 配置中的模型 dict。"""
        raise NotImplementedError

    def summary(self, sys, model):
        """model_summary 的 stocks_in 统计部分：返回参与监控的对象列表。"""
        return sys.all_stocks_for_side(model['side'], model['id'])

    def param_text(self, sys, model):
        """卡片上的参数摘要文本。"""
        cfgm = model.get('config') or {}
        return f"{cfgm.get('threshold')}% / {cfgm.get('window')}分"
