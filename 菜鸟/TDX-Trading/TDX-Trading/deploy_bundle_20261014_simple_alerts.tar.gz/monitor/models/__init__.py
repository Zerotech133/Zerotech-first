# -*- coding: utf-8 -*-
"""监控模型插件包。

REGISTRY: type -> 插件类 的注册表（engine 按 type 分发）。
内置 4 个模型：
    speed  -> metric_model.MetricModel   涨幅预警（卖出止盈）
    drop   -> metric_model.MetricModel   跌幅预警（买入抄底）
    condition    -> cond_model.CondSellModel  卖出条件单
    buy_condition-> cond_model.CondBuyModel   买入条件单
"""

from .base import REGISTRY, BaseModel, register  # noqa: F401

# 导入各插件模块，触发 @register 注册（放尾部避免循环导入）
from . import metric_model   # noqa: E402,F401
from . import cond_model     # noqa: E402,F401
