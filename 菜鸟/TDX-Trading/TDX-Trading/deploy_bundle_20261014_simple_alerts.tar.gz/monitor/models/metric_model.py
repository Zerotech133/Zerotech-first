# -*- coding: utf-8 -*-
"""涨跌幅预警模型插件（speed=涨幅/卖出止盈，drop=跌幅/买入抄底）。

从原 MonitorSystem._compute_model 的通用分支迁出（condition/buy_condition
之外的 type 走这里）。涨跌方向由 type 决定（rises_on），side 只表示
触发后的交易语义。
"""

import threading
import time

import tdx_speed_alert as m

from ..common import TDX_MARKET_TO_QMT, fmt_price, rises_on
from .base import BaseModel, register


@register('speed')
@register('drop')
class MetricModel(BaseModel):
    """涨速/跌幅预警（window 分钟窗口内涨/跌 threshold% 触发）。"""

    def compute(self, sys, model, now, trading, current):
        mid = model['id']
        side = model['side']
        rise = rises_on(model.get('type'))   # 判涨还是判跌，只看 type
        cfgm = model.get('config')
        window = int(cfgm.get('window', 3))
        thr = float(cfgm.get('threshold', 2.0))
        cooldown = int(cfgm.get('cooldown', 60))   # 触发后冷却秒数，避免每 3s 重复上报
        # 从分组展开「绑定了本模型」的该方向股票（跨组去重，携带归属信息）
        stocks_in = sys.all_stocks_for_side(side, mid)

        rows = []
        last_trigger = sys.model_states.get(mid, {}).get('last_trigger')
        top = None  # (code, display_val)
        status = 'idle' if not stocks_in else 'running'
        qmt_signals = []  # 收集要上报QMT的信号

        for s in stocks_in:
            code = s['code']
            stock = (s['market'], code)
            cur = current.get(stock)
            name = s.get('name') or sys.name_of(code) or code
            if not cur:
                rows.append({'code': code, 'name': name, 'price': None,
                             'signed': None, 'value': None, 'prev_price': None,
                             'day_change': None, 'updated': now.strftime('%H:%M:%S'),
                             'alert': False})
                continue
            price = fmt_price(cur['price'])
            yclose = cur['yclose']
            day = (price - yclose) / yclose * 100.0 if yclose else None
            signed = value = prev = None
            alert = False
            if trading:
                res = sys._speed_of(stock, now, window)
                if res:
                    signed, prev = res
                    prev = fmt_price(prev)
                    if rise:
                        value = signed              # 涨幅检测：涨够阈值触发
                        alert = signed >= thr
                    else:
                        value = max(0.0, -signed)   # 跌幅检测：跌够阈值触发
                        alert = signed <= -thr
            rows.append({'code': code, 'name': name, 'price': price,
                         'signed': signed, 'value': value, 'prev_price': prev,
                         'day_change': round(day, 2) if day is not None else None,
                         'updated': now.strftime('%H:%M:%S'), 'alert': alert})

            if alert:
                # 涨幅达标→卖出止盈，跌幅达标→买入抄底（direction 取 model.side）
                signal_label = '涨幅预警' if rise else '跌幅预警'
                now_str = now.strftime('%H:%M:%S')
                now_full = now.strftime('%Y-%m-%d %H:%M:%S')
                mkt_str = TDX_MARKET_TO_QMT.get(s['market'], '')
                # 冷却闸：首次触发立即报，冷却期内静默，到期后再触发再报
                ck = (mid, code)
                ts_now = time.time()
                fired = True                          # 默认允许上报
                if sys._speed_last.get(ck, 0) + cooldown > ts_now:
                    fired = False                     # 还在冷却期，本轮静默
                else:
                    sys._speed_last[ck] = ts_now     # 记录本次上报时间，开启冷却
                # 遍历该股票归属的所有组，按组类型路由推送（仅在 fired 时真正上报）
                has_local = False
                for gi in s['groups']:
                    if gi['group_type'] == 'strategy' and gi['strategy_ids']:
                        # 策略组：为每个绑定的策略各发一条信号
                        if fired:
                            for sid in gi['strategy_ids']:
                                qmt_signals.append({
                                    'strategyId': sid,
                                    'stockCode': code,
                                    'stockName': name,
                                    'market': mkt_str,
                                    'direction': side,
                                    'signalType': signal_label,
                                    'price': price,
                                    'signalTime': now_full,
                                    'reportedBy': 'tdx-monitor',
                                })
                    else:
                        # 自定义组：标记需要本地推送
                        has_local = True
                # 本地推送（自定义组 或 无策略绑定的股票）
                if fired and (has_local or not any(gi['group_type'] == 'strategy' and gi['strategy_ids'] for gi in s['groups'])):
                    m.maybe_alert(stock[0], code, signed, price)
                # 记录预警（仅真正上报时记录，避免冷却期刷屏预警列表）
                if fired:
                    alist = sys._model_alerts.setdefault(mid, [])
                    alist.insert(0, {'time': now_str, 'code': code,
                                     'name': name, 'speed': round(signed, 2), 'price': price})
                    sys._model_alerts[mid] = alist[:50]
                    last_trigger = now_str

            if trading and signed is not None:
                mag = abs(signed) if rise else max(0.0, -signed)
                if top is None or mag > top[1]:
                    top = (code, mag)

        # 批量上报 QMT 信号（异步，不阻塞监控循环）
        if qmt_signals:
            threading.Thread(target=sys.report_signals_qmt,
                             args=(qmt_signals,), daemon=True).start()

        with sys.lock:
            sys.model_states[mid] = {
                'status': status, 'stocks': rows,
                'alerts': sys._model_alerts.get(mid, []),
                'last_trigger': last_trigger,
                'last_update': now.strftime('%H:%M:%S'), 'error': None,
            }
