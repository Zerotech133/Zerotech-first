# -*- coding: utf-8 -*-
"""条件单模型插件（condition=卖出 / buy_condition=买入）。

从原 MonitorSystem._compute_condition / _compute_buy_condition 迁出。
两个模型判定逻辑完全一致，仅 direction 相反（2=卖 / 1=买），
故用参数化基类 + 两个薄子类消除重复。

数据源：sys.qmt_conditions 中匹配 direction 的条件单
（服务端已惰性过期过滤；后端触发/撤销后不再下发，天然幂等）。
"""

import threading
import time

from ..common import (QMT_MARKET_MAP, TDX_MARKET_TO_QMT, fmt_price,
                      market_of, rec_yclose, metric_label_of)
from ..cond_utils import (COND_LABELS2, _cond_window_txt, cond_price,
                          cond_trigger_desc, cond_window_ok, cond_kinds_of)
from .base import BaseModel, register


class CondModelBase(BaseModel):
    """条件单公共判定（direction 由子类指定）。"""

    DIRECTION = None          # 1=买入条件单 2=卖出条件单
    SIDE = None               # 'buy' / 'sell'
    MARKET_STR = None         # 上报信号里的 direction 字段

    def compute(self, sys, model, now, trading, current):
        mid = model['id']
        cfgm = model.get('config') or {}
        cooldown = int(cfgm.get('cooldown', 300))
        now_str = now.strftime('%H:%M:%S')
        now_full = now.strftime('%Y-%m-%d %H:%M:%S')

        rows = []
        last_trigger = sys.model_states.get(mid, {}).get('last_trigger')
        qmt_signals = []

        with sys.lock:
            conditions = [dict(co) for co in sys.qmt_conditions
                          if co.get('direction') == self.DIRECTION]
        for co in conditions:
            sid = co.get('strategy_id')
            # 模型绑定：该策略对应方向的买卖组必须绑定本模型
            if sid is None or not sys._strategy_side_has_model(sid, self.SIDE, mid):
                continue
            code = str(co.get('code', ''))
            if not code:
                continue
            market_num = QMT_MARKET_MAP.get(co.get('market', ''), market_of(code))
            stock = (market_num, code)
            cur = current.get(stock)
            name = co.get('name') or sys.name_of(code) or code
            price = fmt_price(cur['price']) if cur else None
            yclose = rec_yclose(cur) if cur else None
            day = ((price - yclose) / yclose * 100.0) if (price and yclose) else None

            kind, line, gap = _eval_cond_trigger(co, price, yclose)
            alert = bool(kind) and trading
            retrigger = alert and co.get('condition_status') == 1   # 已触发待处理 → 重复提醒
            rows.append({
                'code': code, 'name': name, 'price': price,
                'signed': None, 'value': None, 'prev_price': None,
                'day_change': round(day, 2) if day is not None else None,
                'updated': now_str, 'alert': alert,
                'retrigger': retrigger,
                'condition_order_id': co.get('condition_order_id'),
                'strategy_id': sid,
                'trigger_desc': cond_trigger_desc(co),
                'window_txt': _cond_window_txt(co),
                'expire_date': co.get('expire_date'),
                'cond_kind': kind, 'gap': gap,
            })
            if not alert or kind is None:
                continue

            # 触发 → 上报（反复提醒模式：条件单触发后仍下发仍判定，本地冷却 300s
            # 控制提醒节奏；完结由服务端控制——用户点飞书卡片(markFinished 0/1→4)
            # 或到期(惰性过期)后不再下发，本端同步时自然消失）
            label = COND_LABELS2[kind]
            coid = co.get('condition_order_id')
            ck = (mid, coid)
            if sys._cond_last.get(ck, 0) + cooldown > time.time():
                continue
            sys._cond_last[ck] = time.time()
            qmt_signals.append({
                'strategyId': sid, 'stockCode': code, 'stockName': name,
                'market': TDX_MARKET_TO_QMT.get(market_num, co.get('market', '')),
                'direction': self.MARKET_STR, 'signalType': label,
                'price': price, 'signalTime': now_full,
                'reportedBy': 'tdx-monitor',
                'conditionOrderId': coid,
                'retrigger': retrigger,      # True=重复提醒（已触发过待用户处理）
            })
            alist = sys._model_alerts.setdefault(mid, [])
            alist.insert(0, {'time': now_str, 'code': code, 'name': name,
                             'speed': None, 'price': price,
                             'kind': kind, 'label': label, 'line': line})
            sys._model_alerts[mid] = alist[:50]
            last_trigger = now_str

        if qmt_signals:
            threading.Thread(target=sys.report_signals_qmt,
                             args=(qmt_signals,), daemon=True).start()

        with sys.lock:
            sys.model_states[mid] = {
                'status': 'idle' if not rows else 'running', 'stocks': rows,
                'alerts': sys._model_alerts.get(mid, []),
                'last_trigger': last_trigger,
                'last_update': now_str, 'error': None,
            }

    def summary(self, sys, model):
        """独立条件单：统计服务端下发、方向匹配且策略绑定了本模型的条件单。"""
        mid = model['id']
        with sys.lock:
            conds = [co for co in sys.qmt_conditions
                     if co.get('direction') == self.DIRECTION]
        return [co for co in conds
                if sys._strategy_side_has_model(co.get('strategy_id'),
                                                self.SIDE, mid)]

    def param_text(self, sys, model):
        prefix = '买入' if self.DIRECTION == 1 else ''
        return f'{prefix}条件单：突破/跌破 价格·比例触发'


@register('condition')
class CondSellModel(CondModelBase):
    """卖出条件单（direction=2）。"""
    DIRECTION = 2
    SIDE = 'sell'
    MARKET_STR = 'sell'


@register('buy_condition')
class CondBuyModel(CondModelBase):
    """买入条件单（direction=1）。"""
    DIRECTION = 1
    SIDE = 'buy'
    MARKET_STR = 'buy'


def _eval_cond_trigger(co, price, yclose):
    """条件单触发判定（价格4选1 + 时间窗 + 基准价昨收兜底）。

    返回 (kind, line, gap)：kind=触发的类型（None=未触发/未到窗口），
    line=触发线价格，gap=现价距最近触发线的百分比。
    比例语义 = 当日涨跌幅：锚点一律用昨收价（yclose），无昨收则该比例条件不判定。
    """
    if price is None:
        return None, None, None
    if not cond_window_ok(co):
        return None, None, None
    kinds = cond_kinds_of(co)
    if not kinds:
        return None, None, None
    base = cond_price(yclose)   # 比例锚点 = 昨收价（当日涨跌幅）
    line = None
    for kind in kinds:
        if kind == 'breakout_price':
            ln = co['breakout_price']
        elif kind == 'breakdown_price':
            ln = co['breakdown_price']
        elif kind == 'breakout_ratio':
            ln = base * (1 + co['breakout_ratio']) if base else None
        else:
            ln = base * (1 - co['breakdown_ratio']) if base else None
        if ln is None:
            continue
        hit = (price >= ln) if kind.startswith('breakout') else (price <= ln)
        if hit:
            return kind, round(ln, 2), 0.0
        if line is None or abs(price - ln) < abs(price - line):
            line = round(ln, 2)
    gap = round(abs(price - line) / price * 100.0, 2) if line else None
    return None, line, gap
