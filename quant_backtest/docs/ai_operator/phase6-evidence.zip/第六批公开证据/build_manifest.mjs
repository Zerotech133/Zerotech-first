import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const directory=path.dirname(fileURLToPath(import.meta.url));
const receipts=[];
for(const file of (await readdir(directory)).filter(file=>file.endsWith('.receipt.json')).sort()) {
  const entry=JSON.parse(await readFile(path.join(directory,file),'utf8'));
  const item={receipt_file:file,...entry,archive_bytes_verified:null};
  if(entry.raw_file) {
    const bytes=await readFile(path.join(directory,entry.raw_file));
    item.archive_bytes_verified=bytes.length===entry.size_bytes && createHash('sha256').update(bytes).digest('hex')===entry.sha256;
    if(!item.archive_bytes_verified) throw new Error(`Archive mismatch: ${file}`);
  }
  receipts.push(item);
}
const manifest={schema_version:1,generated_at_utc:new Date().toISOString(),purpose:'第六批A公开材料获取与字节核验清单',counts:{attempts:receipts.length,http_success:receipts.filter(item=>item.success).length,http_failure:receipts.filter(item=>item.status_code!==null&&!item.success).length,transport_failure:receipts.filter(item=>item.transport_error!==null).length,raw_files:receipts.filter(item=>item.raw_file!==null).length},certificate_validation_disabled:false,historical_availability_verified:false,source_authenticated:false,production_eligible:false,receipts};
await writeFile(path.join(directory,'manifest.json'),JSON.stringify(manifest,null,2),'utf8');
console.log(JSON.stringify({counts:manifest.counts,all_archived_bytes_verified:receipts.filter(item=>item.raw_file).every(item=>item.archive_bytes_verified)},null,2));
