param([Parameter(Mandatory=$true)][string]$Url, [Parameter(Mandatory=$true)][string]$Name)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Net.Http
$basePath = $PSScriptRoot
$handler = [System.Net.Http.HttpClientHandler]::new()
$handler.AllowAutoRedirect = $true
$handler.AutomaticDecompression = [System.Net.DecompressionMethods]::None
$client = [System.Net.Http.HttpClient]::new($handler)
$client.Timeout = [TimeSpan]::FromSeconds(45)
$client.DefaultRequestHeaders.UserAgent.ParseAdd('PublicEvidenceArchive/1.0')
$started = [DateTimeOffset]::UtcNow.ToString('o')
$entry = [ordered]@{requested_url=$Url; started_at_utc=$started; completed_at_utc=$null; final_url=$null; status_code=$null; success=$false; transport_error=$null; raw_file=$null; size_bytes=$null; sha256=$null; headers=$null; historical_availability_verified=$false}
try {
    $response = $client.GetAsync($Url).GetAwaiter().GetResult()
    $bytes = $response.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult()
    $entry.final_url = $response.RequestMessage.RequestUri.AbsoluteUri
    $entry.status_code = [int]$response.StatusCode
    $entry.success = $response.IsSuccessStatusCode
    $entry.headers = [ordered]@{response=$response.Headers.ToString(); content=$response.Content.Headers.ToString()}
    $rawPath = Join-Path $basePath ($Name + '.raw.html')
    [System.IO.File]::WriteAllBytes($rawPath, $bytes)
    $entry.raw_file = [System.IO.Path]::GetFileName($rawPath)
    $entry.size_bytes = $bytes.Length
    $entry.sha256 = (Get-FileHash -LiteralPath $rawPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $response.Dispose()
} catch {
    $entry.transport_error = $_.Exception.ToString()
} finally {
    $entry.completed_at_utc = [DateTimeOffset]::UtcNow.ToString('o')
    $json = $entry | ConvertTo-Json -Depth 5
    [System.IO.File]::WriteAllText((Join-Path $basePath ($Name + '.receipt.json')), $json, [System.Text.UTF8Encoding]::new($false))
    $client.Dispose()
    $handler.Dispose()
}
$entry | ConvertTo-Json -Depth 5
