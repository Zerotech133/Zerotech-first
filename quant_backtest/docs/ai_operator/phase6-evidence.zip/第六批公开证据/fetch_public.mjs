import {writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const [url, name] = process.argv.slice(2);
if (!url || !/^[a-z0-9_]+$/.test(name)) throw new Error('Invalid arguments');
const directory = path.dirname(fileURLToPath(import.meta.url));
const entry = {requested_url:url, started_at_utc:new Date().toISOString(), completed_at_utc:null, final_url:null, status_code:null, success:false, transport_error:null, raw_file:null, size_bytes:null, sha256:null, headers:null, client:'Node.js fetch; TLS certificate validation enabled; no authentication', historical_availability_verified:false};
try {
  const response = await fetch(url, {redirect:'follow', signal:AbortSignal.timeout(45000), headers:{'User-Agent':'PublicEvidenceArchive/1.0','Accept-Encoding':'identity'}});
  const bytes = Buffer.from(await response.arrayBuffer());
  entry.final_url = response.url;
  entry.status_code = response.status;
  entry.success = response.ok;
  entry.headers = Object.fromEntries(response.headers);
  entry.raw_file = `${name}.raw.html`;
  entry.size_bytes = bytes.length;
  entry.sha256 = createHash('sha256').update(bytes).digest('hex');
  await writeFile(path.join(directory,entry.raw_file),bytes);
} catch (error) {
  entry.transport_error = String(error.stack ?? error) + (error.cause ? '\nCause: ' + String(error.cause.stack ?? error.cause) : '');
} finally {
  entry.completed_at_utc = new Date().toISOString();
  await writeFile(path.join(directory,`${name}.receipt.json`),JSON.stringify(entry,null,2),'utf8');
}
console.log(JSON.stringify(entry,null,2));
