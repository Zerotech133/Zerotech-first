/**
 * @author JackCHEN
 * @version ${date} ${2022/05/20}
 * @param { String || Number } data 待处理数据
 * @param { Number } decimal 自定义保留的小数位位数默认保留三位
 * @returns { String }
 */
function checkNumber(data, decimal) {
  var val = Number(data);
  if (!isNaN(val) && data != null) {
    return decimal ? val.toFixed(decimal) : val.toFixed(3);
  } else {
    return "-";
  }
}

/**
 * @author JackCHEN
 * @version ${version} ${2022/06/09}
 * @param { String } code 待处理数据
 * @param { Function } cb 回调函数
 */

var filterCodeType = function (code, cb) {
  $.ajax({
    url: sseQueryURL + "commonQuery.do?jsonCallBack=?",
    dataType: "jsonp",
    jsonp: "jsonCallBack",
    type: "GET",
    data: {
      isPagination: false, //是否分页
      sqlId: "COMMON_SSE_ZQLX_C",
      SEC_CODE: code,
    },
    success: function (res) {
      if (res && res.result && res.result.length > 0) {
        cb({
          bigCodeType: res.result[0].SEC_TYPE,
          smallCodeType: res.result[0].SUB_TYPE,
        });
      } else {
        cb({
          bigCodeType: null,
          smallCodeType: null,
        });
      }
    },
  });
};

// 返回当天至前30天(含当天)的时间段
// 默认使用当前时间传参为1时为系统时间
function dateMaxLimit2022(args) {
  try {
    var str = "";
    switch (args) {
      case 1:
        str =
          changeFormatDate(get_systemDate_global(), 0, 0, 0) +
          " - " +
          get_systemDate_global();
        break;
      default:
        str =
          changeFormatDate(
            new Date().toLocaleDateString().split("/").join("-"),
            0,
            0,
            0
          ) +
          " - " +
          new Date().toLocaleDateString().split("/").join("-");
        break;
    }
    if (str) {
      var a = str.split("-");
      str =
        a[0] + "/" + a[1] + "/" + a[2] + "-" + a[3] + "/" + a[4] + "/" + a[5];
    }
    return str;
  } catch (error) {
    console.error(error);
    return null;
  }
}
var lt768Falg = window.screen.width < 768;

var bind_name = "keyup";
var requestNum = 0;
var fixOffsetDefault = 0;
var timeChuoTab;
var timeChuoSearch;
var lastKeyWords = "";
var sseSearch = {
  clickType: "", //点击类型 init|tab|interactive|page
  tabIndexAttr: 0, //当前点击的tabIndexAttr
  searchNullCount: 0, //当前tab位置为0时提示计数
  todayStr: get_systemDate_global(), //公告默认日期
  searchNums: 0, //当前tab位置
  isTitle: true, //当前是标题还是内容(公告用的)
  toBoolean: true, //是否调用公告接口
  selectTypeNum: 0, //默认市场类型：全部
  matchLength: 0,
  chnlData: JSON.parse(JSON.stringify(SSE_MENU_28)),
  /*栏目静态数据*/
  hrefArr: [], //数据想看栏目存储
  isHasList: false, //默认的时候是否有数据
  param: {
    siteUrl: siteUrl,
    searchQueryUrl: {
      /*新全文检索*/
      qwjsNew: "search/getESSearchDoc.do",
      /*全文检索文章埋点*/
      searchTitleClickUrl: "ssequery/search/getClick.do",
      /* 数据列表接口 */
      dataUrl: "search/getDataSearch.do",
      //问答
      faq: "/search/getESSearchFaq.do",
    },
    qwCodeStr: "",
    qwType: 2, //1标题，2是内容
    searchTime: "",
    searchTimeNew: "",
    qwParam: {
      searchword: "",
      page: 1,
      limit: 10,
      spaceId: SSE_SEARCH_RANGE[0].id,
    },
    activeChnlIds: [],
    gsjcs: {},
    searchQueryWord: "", //传参用的变量
    flag: true,
    selectActiveIndex: -1,
  },
  anouncementsFiterItem:[],
  anouncementTag: [],
  allRecomendItems: [
    // 试着这么搜--静态数据
    "20230327股票的成交金额及市价总值",
    "20240325至20240327股票的成交金额及市价总值",
    "融资余额及融券余量金额",
    "2024年3月1日的ETF规模",
    "2024年3月21日转股价大于70的股票",
    "发行价格、初始发行量及中签率",
    "20230327待购回余量",
    "债券收益统计",
    "20240327港股通当日卖出成交笔数",
    "2024年2月27号转融通成交总量及费率",
    "2024年3月27日申报类型及成交总量",
    "认沽成交量及认购成交量",
    "首发募集资金情况",
    "公司送股情况",
    "公司分红信息",
    "20240326到20240327托管市值大于10000亿元的托管只数",
    "股票发行上市审核状态",
    "港股通股票名单",
    "20230327消费ETF的规模",
    "20240327股票市价的总值"
  ],
  progress: null, //定时器  试着这么搜
  //词云图随机数对象
  optionData: [
    {
      name: "IPO信息",
      value: 282,
    },
    {
      name: "成份股",
      value: 273,
    },
    {
      name: "QFII",
      value: 282,
    },
    {
      name: "债券收益统计",
      value: 282,
    },
    {
      name: "分红",
      value: 282,
    },
    {
      name: "送股",
      value: 265,
    },
    {
      name: "两融",
      value: 265,
    },
    {
      name: "高管",
      value: 282,
    },
    {
      name: "ETF规模",
      value: 265,
    },
    {
      name: "上市日期",
      value: 265,
    },
    {
      name: "上证50",
      value: 265,
    },
    {
      name: "港股通",
      value: 273,
    },
    {
      name: "一带一路",
      value: 282,
    },
    {
      name: "审核状态",
      value: 282,
    },
    {
      name: "中签率",
      value: 282,
    },
    {
      name: "优先股",
      value: 282,
    },
  ],
  wordcloudInterval: null, //定时器  词云图
  isModal: false,
  preSearchType: {
    EQU: "股票",
    BON: "债券",
    FUN: "基金",
    WAR: "权证",
    FUT: "期货",
    RCM: "推荐词",
    OTE: "其他",
    IDX: "指数",
  },
  preSearchColor: {
    EQU: "#005fc9",
    BON: "#f57b22",
    FUN: "#ea835f",
    IDX: "#57b1e0",
    WAR: "#9462e6",
    FUT: "#57b1e0",
    RCM: "#a065af",
    OTE: "#cb1235",
  },
  init: function () {
    fixOffsetDefault =
      $(".sse_searchContent ").offset().top - $(".searchHeight").height();
    popularize.setCookie("home-search-scroll", "");//'tab'记录当前位置，‘’不记录当前位置
    fixedStaus = 0;
    //接收参数给搜索框赋值
    try {
      var _this = this;
      var Webswd = "";
      if (getWindowHref().webswd) {
        Webswd = _this.filtrationStr(_this.decodeParam(getWindowHref().webswd));
        Webswd =  this.changeBrowserUrl(Webswd, 50);
      }
      if (Webswd) {
        this.param.searchQueryWord = Webswd ? Webswd : "";
      } else {
        var noHtm =
          '<li class="data_noDaTa">请输入搜索内容，获取您想了解的信息</li>';
        $(".bottom_list .list-group").html(noHtm);
        $(".bottom_list").show();
        //数据频道单独处理
        $(".js_dataTable").html(
          '<div class="data_noDaTa">请输入搜索内容，获取您想了解的信息</div>'
        );
      }
    } catch (error) {}

    require(["highstock"]);
    this.userCommunicationMenuInit(); //必须在loadEvent前执行，一边loadEvent为这个函数创建的用户交流菜单元素绑定事件。
    this.loadEvents();
    this.eventInit();
    if (this.param.searchQueryWord) {
      this.searchInit(this.param.searchQueryWord);
      lastKeyWords = this.param.searchQueryWord;
    }
    this.param.qwType = 2;
    //初始化28full，对自身增加唯一id/
    for (var key in this.chnlData) {
      this.chnlData[key].ID = key;
    }
    this.param.channelCode = {
      announceId: this.getChannelId([
        "8349",
        "12002",
        "8361",
        "8362",
        "12905",
        "9857",
        "9858",
        "9859",
        "9860",
        "9862",
        "9863",
        "9868",
        "9865",
        "9867"
      ]),
      ruleId: this.getChannelId([
        "8640",
        "8659",
        "20643",
        "8687",
        "11601",
        "8702",
      ]),
      newsId: this.getChannelId([
        "13174",
        "8318",
        "8875",
        "8876"
      ]),
      supervisionId: this.getChannelId([
        "15090","10006","10011","10014","10015","9888"
      ],this.getChannelId(["15101","15093","15094","15095","15096"])),
    };
    this.param.anoCode = {
      main: this.getChannelId(["8349"]),
      kcb: this.getChannelId(["12002"]),
      fund: this.getChannelId([
        "8361",
        "8362",
        "12905",
      ]),
      bond: this.getChannelId([
        "9857",
        "9858",
        "9859",
        "9860",
        "9862",
        "9863",
        "9868",
        "9865",
        "9867"
      ]),
    };
    this.anouncementTag = [
      {
        channelId:this.getChannelId(["8349"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["8349"].URL,
        name:"主板股票",
      },{
        channelId:this.getChannelId(["12002"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["8349"].URL,//科创板与主板链接都是最新公告
        name:"科创板股票",
      },{
        channelId:this.getChannelId(["8361"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["8361"].URL,
        name:"基金",
      },{
        channelId:this.getChannelId(["8362"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["8362"].URL,
        name:"基金",
      },{
        channelId:this.getChannelId(["12905"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["12905"].URL,
        name:"基金",
      },{
        channelId:this.getChannelId(["9857"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["9857"].URL,
        name:"债券",
      },{
        channelId:this.getChannelId(["9858"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["9858"].URL,
        name:"债券",
      },{
        channelId:this.getChannelId(["9859"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["9859"].URL,
        name:"债券",
      },{
        channelId:this.getChannelId(["9860"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["9860"].URL,
        name:"债券",
      },{
        channelId:this.getChannelId(["9862"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["9862"].URL,
        name:"债券",
      },{
        channelId:this.getChannelId(["9863"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["9863"].URL,
        name:"债券",
      },{
        channelId:this.getChannelId(["9868"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["9868"].URL,
        name:"债券",
      },{
        channelId:this.getChannelId(["9865"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["9865"].URL,
        name:"债券",
      },{
        channelId:this.getChannelId(["9867"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["9867"].URL,
        name:"债券",
      },{
        channelId:this.getChannelId(["14911"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["14911"].URL,
        name:"债券",
      },{
        channelId:this.getChannelId(["14912"]).split(","),
        url:location.protocol + "//" + SSE_MENU_28[0].URL + SSE_MENU_28["14912"].URL,
        name:"债券",
      }
    ],
    this.param.ruleCode = {
      laws: this.getChannelId(["8640"]),
      department: this.getChannelId(["8659"]),
      rule: this.getChannelId(["20643"]),
      business: this.getChannelId(["8687"]),
      other: this.getChannelId(["11601", "8702"]),
    };
  },
  userCommunicationMenuInit: function () {
    var mobileMenuButton = $(
      ".menu-btn.d-flex.flex-column.justify-content-center.d-md-none"
    );
    mobileMenuButton.before(
      '<div class="user-communication cursor-hand">用户交流</div>'
    );
    var mobileMenu = $("#dl-menu");
    mobileMenu.before(
      '<!-- 用户交流菜单 --><div class="dl-menuwrapper user-comm-dl-menuwrapper d-md-none" id="dl-menu-communication"><button class="dl-menu-button-left" id="dl-menu-communication-button" class="btn"></button><ul class="dl-menu" id="mobile_menu_communication"><li><a href="/xhtml/home/search/AISearch.pdf" target="_blank"><i class= "icon_search2022 icon_search2022_set"></i>功能说明</a></li><li><a href="https://survey.sse.com.cn/q/vX2zkX" target="_blank"><i class="icon_search2022 icon_search2022_quest"></i>体验反馈</a></li></ul></div>'
    );
    $("#dl-menu-communication").dlmenu({ autoCloseOtherdl: true });
  },
  //内容中input、click点击事件
  loadEvents: function () {
    var _this = this;
    if (!lt768Falg) {
      $("#searchword").attr(
        "placeholder",
        "可输入多关键词组合，搜公告、规则等"
      );
      $(".js_page-title").html('<span>上交所网站搜索</span><a class="banner-btn" href="/xhtml/home/search/AISearch.pdf" target="_blank">功能说明<i class= "icon_search2022 search_banner2023_icon_1"></i></a><a class="banner-btn" href="https://survey.sse.com.cn/q/vX2zkX" target="_blank">体验反馈<i class="icon_search2022 search_banner2023_icon_2"></i></a>'); 
    } else {
      $("#searchword").attr("placeholder", "可输入多关键词组合");
      $(".js_page-title").html('<span>上交所网站搜索</span>');
    }
    $(".js_page-title").addClass("show");
    
    /** 2022-全文检索TAB切换 */
    $.each($(".js_navTabs_2022"), function (k, v) {
      $(this).children().eq(0).addClass("active");
    });
    //置顶事件
    $(".js_search_2022_top").click(function () {
      _this.animateScroll(0);
    });
    //默认tab锚点跳转
    $(".sse_disclaimer").on("click", function (e) {
      e.stopPropagation();
      var txtHtm =
        '<div class="search_disclaimerTitle">免责声明</div><div class="search_disclaimerTxt">本网站搜索结果截取自本网站各栏目原内容，搜索结果不能完全取代原内容；任何机构或个人不应视此搜索结果等同于原内容，完整原内容请到各栏目内查看。对任何因直接或间接使用本网站搜索而造成的损失，包括但不限于因有关内容不准确、不完整而导致的损失，上海证券交易所和上证所信息网络有限公司不承担任何法律责任。</div>' +
        '<div class="search_disclaimerBtn"><button type="button" class="btn btn-default" data-dismiss="modal">关闭</button></div>';
      _this.isModal = true;
      _this.disclaimer({
        text: txtHtm,
      });
    });
    //所有的日历插件加载
    _this.getDateInput();
    /* 公用的点击事件 */
    $(".js_navTabs_2022").on("click", function (e) {
      if (!_this.throttlePass(timeChuoTab, 600)) {
        return;
      } else {
        timeChuoTab = new Date().getTime();
      }
      /**生效的参数一定在url上，因此切换url是否存在参数 */
      if (getWindowHref().webswd) {
        $(".valueClear").show();
      } else {
        //无参数时，清空上一次输入的值，下次监听清除按钮会从无到有
        lastKeyWords = "";
        $(".valueClear").hide();
      }

      var index = _this.tabIndexAttr;
      $(this)
        .eq(0)
        .children("span[index=" + index + "]")
        .addClass("active")
        .siblings()
        .removeClass("active");

      $(".tab_main")
        .eq(0)
        .children(".js_content0" + (Number(index) + 1))
        .siblings()
        .fadeOut(100);
      setTimeout(function () {
        $(".tab_main")
          .eq(0)
          .children(".js_content0" + (Number(index) + 1))
          .fadeIn(100);
      }, 100);
      popularize.setCookie("home-search-scroll", "tab");
      _this.animateScroll();

      _this.initHtml(index); //页面初始化
      if ([0, 1, 2, 3, 6].indexOf(index) > -1) {
        _this.searchInit(_this.param.searchQueryWord);
      }
      //gio全文搜索tab切换点击事件
      var tabInfo = "";
      if (index == 0) {
        tabInfo = "全部";
      } else if (index == 1) {
        tabInfo = "公告";
      } else if (index == 2) {
        tabInfo = "数据";
      } else if (index == 3) {
        tabInfo = "新闻";
      } else if (index == 4) {
        tabInfo = "规则";
      } else if (index == 5) {
        tabInfo = "监管";
      } else if (index == 6) {
        tabInfo = "问答";
      }

      try {
        gdp("track", "sseSearchTabClick1", {
          sseSearchTabInfo_var1: tabInfo,
        });
      } catch (error) {}
    });
    /* tab 点击记录选中的是第几个 */
    $(".js_navTabs_2022 span").on("click", function (e) {
      var index = (_this.tabIndexAttr = Number($(this).attr("index")));
      if (_this.searchNums == index) {
        e.stopPropagation();
        return;
      } else {
        clearInterval(_this.progress); //切换tab时清除数据和问答的计时器
        _this.closeDrawer(); //清除定时器
      }
    });
    //搜索标题和搜索正文内容的切换--tab_switch
    $(".search-title .dropdown-menu").on("click", ".dropdown-item", function () {
      $("#search-title").html($(this).html());
      var index = $(this).index();
      if (index == 0) {
        _this.param.qwType = 1;
      } else {
        _this.param.qwType = 2;
      }
      $(".js_content0" + (_this.searchNums + 1) + " .pagination-box").html("");
      //监管、规则codeId初始化
      if (_this.searchNums == 5) {
        _this.param.qwCodeStr = _this.param.channelCode.supervisionId;
        _this.setOtherTabCode(); //处理失效栏目
      } else if (_this.searchNums == 4) {
        _this.param.qwCodeStr = _this.param.channelCode.ruleId;
        _this.setOtherTabCode(); //处理失效栏目
      } else if (_this.searchNums == 2) {
        //数据栏没有切换搜标题逻辑，直接获取数据
        $(".js_dataTable").html("");
        _this.getDataList(); //数据的列表
      } else if (_this.searchNums == 6) {
        //问答栏没有切换搜标题逻辑，直接获取数据
        $(".js_dataTable").html("");
        _this.getFAQ(); //问答
      }else if(_this.searchNums == 3){
        // 新闻栏目
        _this.param.qwCodeStr = _this.param.channelCode.newsId;
        _this.getAllWordsResultNew(0); //处理失效栏目
      } else{
        if (_this.matchLength == 0) {
          _this.searchNullCount = 1;
        } else {
          _this.searchNullCount = 0;
        }
        popularize.setCookie("home-search-scroll", "");
        _this.animateScroll();
        _this.getAllWordsResultNew(0);
      }
    });

    //公告筛选项下方箭头点击关闭筛选框
    $(".close-collapse").click(function(){
      $("#collapseExample").collapse('hide');
    });
    
    //排序单选框点击
    $(".sort_condition").on("click", ".tool_title", function (e) {
      $(this).siblings().removeClass("titleSelected");
      $(this)
        .siblings()
        .find(".iconcirclecheckfull")
        .removeClass("iconcirclecheckfull");
      $(this).find(".iconfont").addClass("iconcirclecheckfull");
      $(this).addClass("titleSelected");
      var index = $(this).index();
      if (index == 0) {
        _this.param.qwParam.orderByKey = "create_time";
        _this.param.qwParam.searchMode = "precise";
      } else {
        _this.param.qwParam.orderByKey = "score";
        _this.param.qwParam.searchMode = "fuzzy";
      }
      if (_this.matchLength == 0) {
        _this.searchNullCount = 1;
      } else {
        _this.searchNullCount = 0;
      }
      _this.getAllWordsResultNew(0);
      e.stopPropagation(); //阻止冒泡
    });

    //搜索范围赋值
    var scopeHtm = "";
    SSE_SEARCH_RANGE.forEach(function (arg) {
      scopeHtm += '<option value="' + arg.id + '">' + arg.name + "</option>";
    });
    //调用bootstrap-select
    bootstrapSelect({
      method: function () {
        $(".js_searchScope .selectpicker")
          .html(scopeHtm)
          .selectpicker("refresh")
          .selectpicker("render");
        //市场类型改变调用参数
        $(".js_searchScope .selectpicker").on(
          "changed.bs.select",
          function (e, clickedIndex, isSelected, previousValue) {
            _this.param.qwParam.spaceId = $(
              ".js_searchScope .selectpicker"
            ).val();
            _this.initFunction();
          }
        );
      },
    });

    $(".sse_outerItem .sse_input").on("focus", function () {
      $(".errorMessage").text("");
    });

    /* 公告 */
    //重置单个选项
    $(".js_ano_reset_content").on("click", ".js_ano_reset_item", function (e) {
      var item_index = $(this).attr("index");
      if(item_index == 0){
        //公告时间去掉选中
        $(".js_anouncements_time .big_title").find(".iconcirclecheckfull").removeClass("iconcirclecheckfull");
        $(".js_anouncements_time .big_title").removeClass("big_active");
        $('.js_searchContent01').val("");
        $(".js_ano_time_start").html("开始时间");
        $(".js_ano_time_end").html("结束时间");
        _this.param.searchTimeNew = "";
      }else{
        //公告类型去掉选中
        var el = $(".js_anouncements_type .big_title").eq(item_index - 1);
        el.find(".iconcirclecheckfull").removeClass("iconcirclecheckfull");
        el.removeClass("big_active");

        _this.setAnoParam();
      }
      _this.anouncementsFiterItem[item_index].isSelected = false;
      _this.renderAnoReset();
      _this.getAllWordsResultNew(0);
    });

    /* 公告 */
    //重置所有选项
    $(".js_ano_reset_content").on("click", ".js_ano_reset_button", function(e){
      $(".search-notice-tool-body .big_title").find(".iconcirclecheckfull").removeClass("iconcirclecheckfull");
      $(".search-notice-tool-body .big_title").removeClass("big_active");
      $('.js_searchContent01').val("");
      $(".js_ano_time_start").html("开始时间");
      $(".js_ano_time_end").html("结束时间");
      _this.anouncementsFiterItem = [
        {
          type: "time",
          text: "",
          isSelected: false
        },{
          type: "anounce",
          text: "主板股票",
          isSelected: false
        },{
          type: "anounce",
          text: "科创板股票",
          isSelected: false
        },{
          type: "anounce",
          text: "债券",
          isSelected: false
        },{
          type: "anounce",
          text: "基金",
          isSelected: false
        }
      ];
      _this.param.searchTimeNew = "";
      _this.setAnoParam();
      _this.renderAnoReset();
      _this.getAllWordsResultNew(0);
    })

    /* 公告 */
    //时间范围选择
    $(".js_anouncements_time").on("click", ".big_title", function (e) {

      //切换了选项时重置时间，自定义时真正切换时机在日期选择器选择了时间
      var title_index = $(this).index();
      if(title_index == 0)return;

      var hasActive = $(this).hasClass("big_active");
      if(!hasActive){
        _this.param.searchTimeNew = "";
        $(".js_anouncements_time .iconcircle").removeClass("iconcirclecheckfull");
        $(".js_anouncements_time .big_title").removeClass("big_active");
        $(this).find(".iconcircle").addClass("iconcirclecheckfull");
        $(this).addClass("big_active");
        
        $(".js_ano_time_start").html("开始时间");
        $(".js_ano_time_end").html("结束时间");

        switch(title_index){
          case 1:
            _this.param.searchTimeNew = get_systemDate_global() + "&&" + get_systemDate_global();
            break;
          case 2:
            _this.param.searchTimeNew = changeFormatDate(get_systemDate_global(), 1, 0, 0) + "&&" + changeFormatDate(get_systemDate_global(), 1, 0, 0);
            break;
          case 3:
            _this.param.searchTimeNew = changeFormatDate(get_systemDate_global(), -7, 0, 0) + "&&" + get_systemDate_global();
            break;
          case 4:
            _this.param.searchTimeNew = changeFormatDate(get_systemDate_global(), -30, 0, 0) + "&&" + get_systemDate_global();
            break;
          case 5:
            _this.param.searchTimeNew = changeFormatDate(get_systemDate_global(), -365, 0, 0) + "&&" + get_systemDate_global();
            break;
          default:
            break;
        }

        _this.anouncementsFiterItem[0].isSelected = true;
        _this.anouncementsFiterItem[0].text = _this.param.searchTimeNew.replace(/\&\&/," - ");
        _this.renderAnoReset();
        _this.getAllWordsResultNew(0);
      }else{
        $(this).find(".iconcircle").removeClass("iconcirclecheckfull");
        $(this).removeClass("big_active");
        _this.param.searchTimeNew = "";
        _this.anouncementsFiterItem[0].isSelected = false;
        _this.anouncementsFiterItem[0].text = '';
        _this.renderAnoReset();
        _this.getAllWordsResultNew(0);
      }
    });

    /* 公告 */
    //类型赋值
    $(".js_anouncements_type").on("click", ".big_title", function (e) {
      var hasActive = $(this).hasClass("big_active");
      if (hasActive) {
        $(this).find(".iconcirclecheckfull").removeClass("iconcirclecheckfull");
        $(this).removeClass("big_active");
        _this.anouncementsFiterItem[$(this).index()+1].isSelected = false;
        _this.renderAnoReset();
      } else {
        $(this).find(".iconcircle").addClass("iconcirclecheckfull");
        $(this).addClass("big_active");
        _this.anouncementsFiterItem[$(this).index()+1].isSelected = true;
        _this.renderAnoReset();
      }
      _this.setAnoParam();
    });


    /* 规则 */
    //类型赋值
    var ruleHtm =
      '<div class="big_title" name="laws"><span class="iconfont iconcircle"></span>法律法规</div>' +
      '<div class="big_title" name="department"><span class="iconfont iconcircle"></span>部门规章</div>' +
      '<div class="big_title" name="rule"><span class="iconfont iconcircle"></span>本所业务规则</div>' +
      '<div class="big_title" name="business"><span class="iconfont iconcircle"></span>业务指南</div>' +
      '<div class="big_title" name="other"><span class="iconfont iconcircle"></span>其他</div>';
    $(".rule_type .search_typeCon").html(ruleHtm);
    //类型选择
    $(".rule_type").on("click", ".big_title", function (e) {
      var hasActive = $(this).hasClass("big_active");
      if (hasActive) {
        $(this).find(".iconcirclecheckfull").removeClass("iconcirclecheckfull");
        $(this).removeClass("big_active");
      } else {
        $(this).find(".iconcircle").addClass("iconcirclecheckfull");
        $(this).addClass("big_active");
      }
      _this.setRuleParam();
    });
    //删除
    $(".js_ruleOption").on("click", "i", function () {
      var nameOne = $(this).parent().attr("name");
      $(this).parent().remove();
      $(".rule_type")
        .find("[name='" + nameOne + "']")
        .click();
    });
    //重置
    $(".js_content05 .search_reset").on("click", function () {
      _this.param.searchTime = "";
      $(".js_ruleDate").val(""); //清空日期
      $(".rule_type .big_title").removeClass("big_active");
      $(".rule_type .iconcircle").removeClass("iconcirclecheckfull");
      _this.setRuleParam();
    });

    /*数据*/
    //试一试
    $(".try_btn").on("click", function () {
      var parentObj = $(this).parents(".try_search");
      var isTop = parentObj.hasClass("try_top");
      if (isTop) {
        //试试这么搜
        clearInterval(_this.progress); //清除定时器
        _this.filterHis();
        _this.progress = setInterval(function () {
          _this.filterHis();
        }, 10000);
      } else {
        //词云图
        _this.closeDrawer(); //清除定时器
        _this.showWordcloud(); //加载词云图
        _this.wordcloudInterval = setInterval(function () {
          _this.showWordcloud();
        }, 10000); //定时刷新
      }
    });
    //点击试一试li 进行检索
    $(".try_list").on("click", "li", function () {
      _this.param.searchQueryWord = _this.changeBrowserUrl($(this).find("span").text(), 50);;
      _this.searchInit(_this.param.searchQueryWord);
    });
  },
  //搜索框事件绑定
  eventInit: function () {
    var _this = this;
    $(".js_queryBtn").click(function () {
      //增加搜索节流效果
      if (!_this.throttlePass(timeChuoSearch, 1000)) {
        return;
      } else {
        timeChuoSearch = new Date().getTime();
      }
      var inputContent = _this.filtrationStr($.trim($("#searchword").val()));
      $("#searchword").val(inputContent);
      if (!inputContent) {
        alert("请输入搜索关键词");
        return;
      }
      popularize.setCookie("home-search-scroll", "tab");
      _this.animateScroll();
      var inputContentNew = _this.changeBrowserUrl(inputContent, 50);
      _this.param.searchQueryWord = inputContentNew;
      _this.searchInit(_this.param.searchQueryWord,'operateReSearch');
    });
    _this.closeEventAdd(".bg_8307 .sse_searchBorder_hasClear .search-title");
    var timer = setTimeout(function () {
      _this.closeEventInit("searchword", "searchword");
      clearTimeout(timer);
    }, 0);

    var timeoutId;
    var flag;

    /**  判断设备切换键盘监听事件   */
    var isIOS = !!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
    if (isIOS) {
      bind_name = "input";
    }
    //鼠标点击输入框
    $("#searchword")
      .focus(function (e) {
        e.preventDefault();
        $(".sse_searchBorder").addClass("sse_searchActive");
      })
      .on("blur", function () {
        $(".sse_searchBorder").removeClass("sse_searchActive");
      });
    $("#searchword").bind(bind_name, function (e) {
      e.preventDefault();
      var inputContent = $.trim($("#searchword").val()) || "";
      var key = e.which;
      var isClickEnter =
        key == 13 || (key == 10 && $.browser.msie && $.browser.version <= 6.0);
      if (isClickEnter) {
        //增加搜索节流效果
        if (!_this.throttlePass(timeChuoSearch, 1000)) {
          return;
        } else {
          timeChuoSearch = new Date().getTime();
        }
        inputContent = _this.filtrationStr(inputContent);
        $("#searchword").val(inputContent);
        if (!inputContent) {
          alert("请输入搜索关键词");
          return;
        }
        popularize.setCookie("home-search-scroll", "tab");
        _this.animateScroll();
        var inputContentNew = _this.changeBrowserUrl(inputContent, 50);
        _this.param.searchQueryWord = inputContentNew;
        _this.searchInit(_this.param.searchQueryWord,'operateReSearch');
      } else {
        //新增字符输入监听
        if (!lastKeyWords && !inputContent) {
          //nothing to do
        } else if (!lastKeyWords && inputContent) {
          $(".valueClear").show();
          lastKeyWords = inputContent;
        } else if (lastKeyWords && !inputContent) {
          $(".valueClear").hide();
          lastKeyWords = inputContent;
        } else if (lastKeyWords && inputContent) {
          //nothing to do
        }
      }
      if (flag) {
        clearTimeout(timeoutId);
      }
      timeoutId = setTimeout(function () {
        flag = false;
      }, 250);
      flag = true;
    });
    $(document).click(function (e) {
      if (
        !$("#searchword").is(e.target) &&
        $("#searchword").has(e.target).length === 0
      ) {
        $("#searhInput").hide().find("ul").empty();
      }
    });
  },
  renderAnoReset: function(){
    var _this = this;
    var count = 0;
    var htm = '';
    _this.anouncementsFiterItem.forEach(function(arg,index){
      if(arg.isSelected){
        count++;
        htm += '<div class="search-notice-reset-item">'+arg.text+'<span type="'+ arg.type +'" index="'+ index +'" class="iconfont bi-x-circle js_ano_reset_item"></span></div>'
      }
    });
    htm += '<div class="search_reset js_ano_reset_button">清空<i class="iconfont iconreset"></i></div>';
    if(count){
      $(".search-notice-reset-box").show();
    }else{
      $(".search-notice-reset-box").hide();
    }
    $(".js_ano_reset_content").html(htm);
  },
  /**
   * 搜索框关闭事件dom渲染
   * @param {*} className
   */
  closeEventAdd: function (className) {
    $(className).append('<span class="valueClear bi bi-x"></span>');
    $(".valueClear").hide();
  },
  /**
   * 搜索框关闭事件绑定
   * @param {*} id input id
   * @param {*} name input name
   */
  closeEventInit: function (id, name) {
    if ($.trim($("#searchword").val())) {
      $(".valueClear").show();
    }
    $(".valueClear").click(function (e) {
      if ($.trim($("#" + id).val())) {
        $("#" + id).val("");
        lastKeyWords = "";
        $(".valueClear").hide();
        $("input[name='" + name + "']").focus();
        e.preventDefault();
      }
    });
  },
  //检索初始化
  initFunction: function () {
    var _this = this;
    if ($.trim(_this.param.searchQueryWord)) {
      if (_this.searchNums == 0) {
        _this.searchNullCount = 0;
        //股票推荐
        $(".js_chartCon").hide();
        $(".js_companyDetail").hide();
        $(".js_content01 .search_bg .search_padding").hide("");
        $(".js_content01 .search_columns").hide("");
        if (_this.param.qwParam.spaceId == SSE_SEARCH_RANGE[0].id) {
          var filterSearchQueryWord = _this.param.searchQueryWord.replace(/[\*\(\)\[\]]/g,'');
          if(filterSearchQueryWord){
            _this.resultTableFunction({
              searchWord: filterSearchQueryWord,
            });
          }
        }

        //全文检索
        _this.getAllWordsResultNew(0);
      } else if (_this.searchNums == 1) {
        _this.getAllWordsResultNew(0);
      } else if (
        _this.searchNums == 3 ||
        _this.searchNums == 4 ||
        _this.searchNums == 5
      ) {
        _this.getAllWordsResultNew(0);
      } else if (_this.searchNums == 2) {
        $(".js_dataTable").html("");
        _this.getDataList(); //数据的列表
      } else if (_this.searchNums == 6) {
        $(".js_dataTable").html("");
        _this.getFAQ(); //问答
      }
    }
    if (_this.searchNums == 2 || _this.searchNums == 6) {
      //试试搜这些
      clearInterval(_this.progress);
      _this.filterHis();
      _this.progress = setInterval(function () {
        _this.filterHis();
      }, 10000);
      //词云图
      _this.setPolyfill(); //词云图ie兼容需要加载的Polyfill
      _this.closeDrawer(); //清除定时器
      setTimeout(function () {
        _this.showWordcloud(); //加载词云图
      }, 100);
      _this.wordcloudInterval = setInterval(function () {
        //定时刷新
        _this.showWordcloud();
      }, 10000);
    }
  },
  //搜索词存入cookie，调用初始化检索方法
  searchInit: function (val,triggerEvent) {
    var _this = this;
    //输入框赋值、页面初始化
    $("#searchword").val(val);
    //公共部分
    $(".search_option").html(""); //筛选
    $(".pagination-box").html(""); //分页清空
    if (_this.param.searchQueryWord) {
      $(".bottom_list ul").html(""); //列表
    }
    $(".search_columns").hide(); //想看的栏目
    //总条数从几条到几条
    $(".search_total").text(0);
    $(".search_start").text(0);
    $(".search_end").text(0);
    if (_this.searchNums == 0) {
      $(".js_chartCon").hide();
      $("#econtent").html("");
      $(".js_companyDetail .table").html("");
    }
    //初始化排序，点击搜索时进入次方法
    _this.param.qwParam.orderByDirection = "DESC";
    if(_this.searchNums == 1){
      _this.param.qwParam.orderByKey = "create_time";
      _this.param.qwParam.searchMode = "precise";//公告栏只有精确搜索
      //公告栏重新搜索时清空所有选项并收起筛选项
      _this.initHtml(1,triggerEvent);
      $("#collapseExample").collapse('hide');//更换搜索词时收起筛选项
    }else{
      var orderByKeyStr = $(".js_content0" + (_this.searchNums + 1) + " .titleSelected").index();
      _this.param.qwParam.orderByKey =
        orderByKeyStr == 0 ? "create_time" : "score";
      _this.param.qwParam.searchMode =
        orderByKeyStr == 0 ? "precise" : "fuzzy";
    }
    
    var val = val.replace(/[<>"';)(:&!$^]/g, "");
    var seecookie = popularize.getCookie("seecookie");
    var newCookie = seecookie.split(",");
    if (newCookie.length > 4) {
      newCookie.shift();
    }
    if (newCookie.indexOf(val) == -1) {
      if (newCookie[0] == "") {
        newCookie = [];
      }
      newCookie.push(val);
      var newcookstr = newCookie.join(",");
      popularize.setCookie("seecookie", newcookstr);
    }
    $("#searhInput").hide().find("ul").empty();
    _this.param.selectActiveIndex = -1;
    var searchword = $("#searchword").val();
    if (searchword.length > 0) {
      //过滤特殊字符
      searchword = _this.filtrationStr(searchword);
      searchword = searchword.replace(/'/g, "\\'");
      searchword = searchword.replace(/\s+/g, " ");
      if ($.trim(searchword) != "") {
        searchword = $.trim(searchword);
      }
    }
    _this.param.searchQueryWord = searchword; //传参
    //初始化方法
    _this.initFunction();

    //gio全文搜索点击事件计数--sseSearchClick1
    try {
      gdp("track", "sseSearchClick1", {
        sseSearchInfo_var1: searchword,
      });
    } catch (error) {}
  },
  //编码接收的参数
  decodeParam: function (val) {
    return decodeURIComponent(val);
  },
  /**
   * @author JackCHEN
   * @methods { detailStock} 处理股票标题code和简称的展示
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   */
  detailStock: function (obj) {
    var cHtm = "";
    var href = ' target="_blank" href="/assortment/stock/list/info/company/index.shtml?COMPANY_CODE=' + obj.code;
    cHtm +=
      '<a class="chart_title" ' +
      href +
      '">' +
      obj.word +
      "</a>";
    cHtm +=
      '<a class="chart_code" ' +
      href +
      '">' +
      " ( " +
      obj.code +
      " ) " +
      "</a>";
    cHtm +=
      '<a class="bi-chevron-right" ' +
      href +
      '"></a>';
    $(".search_chartTitle").html(cHtm);
  },
  /**
   * @author JackCHEN
   * @methods { detailBund}  处理债券类型标题code和简称的展示
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   */
  detailBund: function (obj) {
    var linkUrl = "javascript:void(0)";
    var cHtm = "";
    cHtm +=
      '<a class="chart_title" href="' + linkUrl + '">' + obj.word + "</a>";
    cHtm +=
      '<a class="chart_code" href="' +
      linkUrl +
      ' ">' +
      " ( " +
      obj.code +
      " ) " +
      "</a>";
    $(".search_chartTitle").html(cHtm);
  },
  /**
   * @author JackCHEN
   * @methods { detailFund}  处理基金类型标题code和简称的展示
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   */
  detailFund: function (obj) {
    var fundUrl = this.getFundLink(obj),
      cHtm = "";
    if (fundUrl) {
      cHtm += '<a class="chart_title" ' + fundUrl + ">" + obj.cpxxextendname + "</a>";
      cHtm +=
        '<a class="chart_code" ' +
        fundUrl +
        ">" +
        " ( " +
        obj.code +
        " ) " +
        "</a>";
      if (fundUrl != "javascript:void(0)") {
        cHtm += '<a class="bi-chevron-right" ' + fundUrl + "></a>";
      }
    } else {
      cHtm += '<span class="chart_title">' + obj.cpxxextendname + "</span>";
      cHtm +=
        '<span class="chart_code">' + " ( " + obj.code + " ) " + "</span>";
    }
    $(".search_chartTitle").html(cHtm);
  },
  /**
   * @author JackCHEN
   * @methods { detailHead} 区分股票，债券和基金并分别处理
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   */
  detailHead: function (obj) {
    // 按类型划分模块处理
    _this = this;
    switch (obj.codeType.bigCodeType) {
      case "ES":
        _this.detailStock(obj); // 处理股票数据
        break;
      case "D":
        _this.detailBund(obj); // 处理债券数据
        break;
      case "EU":
      case "CB":
        _this.detailFund(obj); // 处理基金基金数据
        break;
    }
  },
  /**
   * @author JackCHEN
   * @methods { detailHeadStock}  处理股票类型行情数据渲染及简称后的标识
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  dataObj  传入的code相关的行情数据
   */
  detailHeadStock: function (dataObj) {
    $(".chart_title").text(
      $(".chart_title").text() + kcbShowIconFlag(dataObj.qqhqList[12])
    );

    $("#c2").text((dataObj._volume / 100).toFixed(0));  //成交量（手）
    $("#c10").text((dataObj._fp_volume / 100).toFixed(0));  //盘后成交量（手）
    var new_price =
      Number(checkNumber(dataObj._pice, 2)) != 0
        ? checkNumber(dataObj._pice, 2)
        : 0;
    var open_price = checkNumber(dataObj._open, 2);
    var high_price = checkNumber(dataObj._high, 2);
    var yesterday_price = checkNumber(dataObj._preClose, 2);
    var low_price = checkNumber(dataObj._low, 2);
    $("#c1").text(new_price);
    $("#c6").text(open_price);
    $("#c8").text(high_price);
    $("#c7").text(yesterday_price);
    $("#c9").text(low_price);
    $("#c12").text(getTradephaseText(dataObj._tradephase));
    $("#c13").text(getFpphaseText(dataObj._fp_phaseArr));
  },
  /**
   * @author JackCHEN
   * @methods { detailHeadBund}  处理债券类型行情数据渲染及简称后的标识
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   * @param { Object }  dataObj  传入的code相关的行情数据
   */
  detailHeadBund: function (obj, dataobj) {
    $("#y1").text("千元面额");
    $("#c2").text(dataobj._volume.toFixed(0));
    if (obj.codeType == "huigou") {
      $("#y1").text("手");
    }
    var new_price, open_price, high_price, yesterday_price, low_price;
    new_price =
      Number(checkNumber(dataobj._pice)) != 0 ? checkNumber(dataobj._pice) : 0;
    open_price = checkNumber(dataobj._open);
    high_price = checkNumber(dataobj._high);
    yesterday_price = checkNumber(dataobj._preClose);
    low_price = checkNumber(dataobj._low);
    $("#c1").text(new_price);
    $("#c6").text(open_price);
    $("#c8").text(high_price);
    $("#c7").text(yesterday_price);
    $("#c9").text(low_price);
  },
  /**
   * @author JackCHEN
   * @methods { detailHeadBund}  处理基金类型行情数据渲染及简称后的标识
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   * @param { Object }  dataObj  传入的code相关的行情数据
   */
  detailHeadFund: function (dataObj) {
    $("#c2").text((dataObj._volume / 100).toFixed(0));
    var new_price = Number(checkNumber(dataObj._pice, 3)) != 0 ? checkNumber(dataObj._pice, 3) : 0;
    //基金涨跌保留3位小数
    var _pchange = Number(checkNumber(dataObj._pchange, 3)) != 0 ? checkNumber(dataObj._pchange, 3) : '0.000';
    var open_price = checkNumber(dataObj._open, 3);
    var high_price = checkNumber(dataObj._high, 3);
    var yesterday_price = checkNumber(dataObj._preClose, 3);
    var low_price = checkNumber(dataObj._low, 3);
    $("#c1").text(new_price);
    $("#c4").text(_pchange);
    $("#c6").text(open_price);
    $("#c8").text(high_price);
    $("#c7").text(yesterday_price);
    $("#c9").text(low_price);
  },
  /**
   * @author JackCHEN
   * @methods { detailHeadNum} 区分股票，债券和基金并分别处理
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   * @param { Object } resultData 传入的code相关的行情涨跌幅数据
   */
  detailHeadNum: function (obj, resultData) {
    var _this = this,
      // 通用数据处理
      dataObj = {
        qqhqList: resultData.snap,
        _isShow: resultData.snap[10],
        _pice: resultData.snap[1],
        _amount: resultData.snap[2],
        _volume: resultData.snap[3],
        _pchange: resultData.snap[4],
        _chg_rate: resultData.snap[5],
        _open: resultData.snap[6],
        _preClose: resultData.snap[7],
        _high: resultData.snap[8],
        _low: resultData.snap[9],
        _tradephase: resultData.snap[10],
        _fp_volume: resultData.snap[14],
        _fp_amount: resultData.snap[15],
        _fp_phaseArr: resultData.snap[16],
      };
    // 通用逻辑处理
    if (dataObj.qqhqList.length < 1) {
      $("#econtent").empty();
      $("#econtent").append(
        '<div class="d-flex align-items-center justify-content-center noChart_message">暂无走势信息</div>'
      );
    }
    if (dataObj._tradephase.replace(/\s/gi, "") == "P1") {
      $("#econtent").empty();
      $("#econtent").append(
        '<div class="d-flex align-items-center justify-content-center noChart_message">停牌中</div>'
      );
    } else if (dataObj._tradephase.replace(/\s/gi, "") == "C1") {
      $("#econtent").empty();
      $("#econtent").append(
        '<div class="d-flex align-items-center justify-content-center noChart_message">集合竞价中</div>'
      );
    }
    //渲染页面数据
    $("#c3").text((dataObj._amount / 10000).toFixed(0)); // 成交额（万元）
    $("#c11").text((dataObj._fp_amount / 10000).toFixed(0)); //盘后成交额（万元）
    $("#c4").text(parseFloat(dataObj._pchange.toFixed(3)));
    $("#c5").text(parseFloat(dataObj._chg_rate.toFixed(3)) + "%");

    switch (obj.codeType.bigCodeType) {
      case "ES":
        _this.detailHeadStock(dataObj); // 处理股票数据
        break;
      case "D":
        _this.detailHeadBund(obj, dataObj); // 处理债券数据
        break;
      case "EU":
      case "CB":
        _this.detailHeadFund(dataObj); // 处理基金数据
        break;
    }
    //根据涨跌切换字体颜色
    if (dataObj._tradephase.replace(/\s/gi, "") == "P1") {
      $("#c1").addClass();
      $("#c4").addClass();
      $("#c5").addClass();
    } else {
      if (dataObj._chg_rate > 0) {
        $("#c1").addClass("trending-up").removeClass("trending-down");
        $("#c4").addClass("trending-up").removeClass("trending-down");
        $("#c5").addClass("trending-up").removeClass("trending-down");
      } else if (dataObj._chg_rate < 0) {
        $("#c1").addClass("trending-down").removeClass("trending-up");
        $("#c4").addClass("trending-down").removeClass("trending-up");
        $("#c5").addClass("trending-down").removeClass("trending-up");
      } else {
        $("#c1").removeClass("trending-down").removeClass("trending-up");
        $("#c4").removeClass("trending-down").removeClass("trending-up");
        $("#c5").removeClass("trending-down").removeClass("trending-up");
      }
    }
    if (dataObj._open.toFixed(2) > dataObj._preClose.toFixed(2)) {
      $("#c6").removeClass("trending-down").addClass("trending-up");
    } else if (dataObj._open.toFixed(2) < dataObj._preClose.toFixed(2)) {
      $("#c6").removeClass("trending-up").addClass("trending-down");
    } else {
      $("#c6").removeClass("trending-down").removeClass("trending-up");
    }
  },

  /**
   * @author JackCHEN
   * @methods { detailStockAnnoucement}  处理股票类型最新公告内容展示
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   */
  detailStockAnnoucement: function (obj) {
    var alphaA = "";
    alphaA =
      '<a target="_blank" class="active" href="/assortment/stock/list/info/company/index.shtml?COMPANY_CODE=' +
      obj.code +
      '&tabActive=1">最新公告<span class="bi-chevron-right"></span></a>';
    $(".search_rightLinks").html(alphaA);

    $.getScript(
      siteUrl + "/js/common/stocks/new/" + obj.code + ".js",
      function () {
        var wstockData = eval("get_" + obj.code + "()");
        var stockEleArr = "";
        $.each(wstockData, function (idx, item) {
          if (idx < 5) {
            stockEleArr += '<li class="d-flex list-group-item">';
            stockEleArr += '<div class="search_listTitle">';
            stockEleArr +=
              '<a target="_blank"  href="' +
              siteUrl +
              item.bulletin_file_url +
              '">';
            stockEleArr +=
              (item.is_holder_disclose == 1 ? "<em>股东自行披露</em>" : "") +
              item.bulletin_title;
            stockEleArr += "</a>";
            stockEleArr += "</div>";
            stockEleArr +=
              '<span class="text-nowrap new_date">' +
              item.bulletin_date +
              "</span>";
            stockEleArr += "</li>";
          }
          if (stockEleArr == "") {
            stockEleArr +=
              '<li class="d-flex list-group-item border-bottom-0">';
            stockEleArr += "暂无数据";
            stockEleArr += "</li>";
          }
          $(".search_rightList ul").html(stockEleArr);
        });
      }
    );
  },

  /**
   * @author JackCHEN
   * @methods { detailBondAnnoucement}  处理债券类型最新公告内容展示
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   */
  detailBondAnnoucement: function (obj) {
    $(".search_rightLinks").html('<span class="active">最新公告</span>');
    var bondata = {
      isPagination: true,
      "pageHelp.pageSize": 5,
      "pageHelp.cacheSize": 1,
      type: "inParams", //默认全部
      sqlId: "BS_ZQ_GGLL",
      sseDate:
        changeFormatDate(get_systemDate_global(), 0, 0, -3) + " 00:00:00", //结束日期
      sseDateEnd:
        changeFormatDate(get_systemDate_global(), 0, 1, 0) + " 23:59:59", //开始日期
      securityCode: obj.code, //证券代码
      title: "", //关键字
      orgBulletinType: "", //公告类型
      bondType: "",
      order: "sseDate|desc,securityCode|asc,bulletinId|asc",
    };
    //债券BON
    this.detailBondResultAjax(sseQueryURL + "commonSoaQuery.do", bondata);
  },
  /**
   * @author JackCHEN
   * @methods { detailFundAnnoucement}  处理基金类型最新公告内容展示
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   */
  detailFundAnnoucement: function (obj) {
    $(".search_rightLinks").html('<span class="active">最新公告</span>');
    var fundata = {
      isPagination: true,
      "pageHelp.pageSize": 5,
      "pageHelp.pageNo": 1,
      "pageHelp.beginPage": 1,
      "pageHelp.cacheSize": 1,
      "pageHelp.endPage": 1,
      type: "inParams",
      sqlId: "COMMON_PL_JJXX_JJGG_NEW_L",
      TITLE: "", //关键字
      SECURITY_CODE: obj.code, //证券代码
      BULLETIN_TYPE:
        "reits01,fund01,reits02,fund02,reits03,fund03,reits04,fund04,reits05,fund05,reits06,fund06",
      START_DATE: changeFormatDate(get_systemDate_global(), 0, 0, -3), //结束日期
      END_DATE: changeFormatDate(get_systemDate_global(), 0, 1, 0), //开始日期
      DATE_DESC: 1,
      DATE_ASC: "",
      CODE_DESC: "",
      CODE_ASC: "",
    };
    //基金、etf
    this.detailFundResultAjax(sseQueryURL + "commonQuery.do", fundata);
  },
  /**
   * @author JackCHEN
   * @methods { detailLatestAnnouncement } 区分股票，债券和基金并分别处理
   * @version 创建时间：${date} ${2023/05/31}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   */
  detailLatestAnnouncement: function (obj) {
    switch (obj.codeType.bigCodeType) {
      case "ES":
        _this.detailStockAnnoucement(obj); // 处理股票数据
        break;
      case "D":
        _this.detailBondAnnoucement(obj); // 处理债券数据
        break;
      case "EU":
      case "CB":
        _this.detailFundAnnoucement(obj); // 处理基金数据
        break;
      default:
        return;
    }
  },
  /**
   * @author JackCHEN
   * @methods { detailAjax} 处理传入的code值以及控制页面的渲染
   * @version 创建时间：${date} ${2023/05/31}
   * @param { String } code 传入的行情code值，分别对应基金，债券和股票
   * @param { Function } cb 回调函数，为和原逻辑保持一致性，回传调用成功的状态值修改调用函数父作用域内的状态值
   */
  detailAjax: function (code) {
    _this = this;
    filterCodeType(code, function (res) {
      //判断code数据类型，可用数据类型分别是基金，债券和股票非可用类型不展示行情数据
      $(".js_chartCon").hide();
      if (res && res.bigCodeType) {
        $.ajax({
          // 是基金，债券和股票类型调用行情数据接口
          type: "post",
          url:
            hq_queryUrl +
            (res.bigCodeType == "D" ? hqBondUrl : hqOthUrl) +
            "snap/" +
            code,
          data: {
            select:
              "name,last,amount,volume,change,chg_rate,open,prev_close,high,low,tradephase,cpxxsubtype,cpxxprodusta,cpxxextendname,fp_volume,fp_amount,fp_phase",
          },
          dataType: "jsonp",
          jsonp: "callback",
          success: function (resultData) {
            if (resultData && resultData.snap && resultData.snap.length > 0) {
              var detailObj = {
                codeType: res,
                code: resultData.code,
                word: resultData.snap[0],
                cpxxextendname: resultData.snap[13]
              };
              //只显示大类为股票ES，小类为ASH主板A和科创板KSH的行情图和最新公告
              if(res.bigCodeType == "ES" && ['ASH','KSH'].indexOf(res.smallCodeType) > -1){
                _this.detailHead(detailObj); // 处理对应code名称以及对应的跳转关系
                //B股不跳转并且不显示右边最新公告
                _this.detailLatestAnnouncement(detailObj); // 处理对应code最新公告内容
                _this.detailHeadNum(detailObj, resultData); // 处理对应code具体数据内容
                $(".js_chartCon").show();
              }
            }
          },
        });
        $("#econtent").empty();
        $("#econtent").append(
          '<div class="d-flex align-items-center justify-content-center noChart_message">暂无走势信息</div>'
        );
        //基金，etf，债券，指数行情图，2023/06/15改动为只显示A股
        if(res.bigCodeType == "ES" && ['ASH','KSH'].indexOf(res.smallCodeType) > -1){
          drawOneSmallZChart(code, "econtent", true, "#econtent");
        }
      }
    });
  },

  //股票详情
  resultTableFunction: function (obj) {
    var _this = this;
    var searchWord = obj.searchWord;
    _this.detailAjax(searchWord);
  },
  /**
   * @author JackCHEN
   * @methods { detailFundResultAjax}  处理基金类型最新公告内容调用接口
   * @version 创建时间：${date} ${2023/06/08}
   * @param { String }  url  接口查询url地址
   * @param { allData } allData  查询的相关参数
   */
  detailFundResultAjax: function (url, allData) {
    var _this = this;
    _this.searchJSONP({
      type: "post",
      url: url,
      data: allData,
      timeout: 10000,
      successCallback: function (res) {
        if (res && res.result && res.result.length > 0) {
          var stockEleArr = "";
          $.each(res.result, function (idx, item) {
            if (idx < 5) {
              var isUrlHttp = item.URL
                ? /^https:|http:|\/\//i.test(item.URL)
                : item.docURL
                ? /^https:|http:|\/\//i.test(item.docURL)
                : ture;
              stockEleArr +=
                '<li class="d-flex justify-content-between list-group-item">';
              stockEleArr += '<div class="search_listTitle">';
              if (!isUrlHttp) {
                var isWWW = item.URL
                  ? /^www/i.test(item.URL)
                  : item.docURL
                  ? /^www/i.test(item.docURL)
                  : false;
                if (isWWW) {
                  stockEleArr +=
                    '<a target="_blank"  href="' +
                    (item.URL
                      ? "http://" + item.URL
                      : item.docURL
                      ? "http://" + item.docURL
                      : "#") +
                    '">';
                } else {
                  stockEleArr +=
                    '<a target="_blank"  href="' +
                    (item.URL ? item.URL : item.docURL ? item.docURL : "#") +
                    '">';
                }
              } else {
                stockEleArr +=
                  '<a target="_blank"  href="' +
                  (item.URL ? item.URL : item.docURL ? item.docURL : "#") +
                  '">';
              }
              stockEleArr += item.TITLE || item.docTitle;
              stockEleArr += "</a>";
              stockEleArr += "</div>";
              stockEleArr +=
                '<span class="text-nowrap new_date">' +
                (item.SSEDATE
                  ? item.SSEDATE
                  : item.createTime.substring(
                      0,
                      item.createTime.indexOf(" ")
                    )) +
                "</span>";
              stockEleArr += "</li>";
            }
          });
        } else {
          stockEleArr +=
            '<li class="d-flex justify-content-between list-group-item border-bottom-0">';
          stockEleArr += "暂无数据";
          stockEleArr += "</li>";
        }
        $(".search_rightList ul").html(stockEleArr);
      },
      errCallback: function () {
        stockEleArr +=
          '<li class="d-flex justify-content-between list-group-item border-bottom-0">';
        stockEleArr += "暂无数据";
        stockEleArr += "</li>";
        $(".search_rightList ul").html(stockEleArr);
      },
    });
  },
  /**
   * @author JackCHEN
   * @methods { detailBondResultAjax}  处理债券类型最新公告内容调用接口
   * @version 创建时间：${date} ${2023/06/08}
   * @param { String }  url  接口查询url地址
   * @param { allData } allData  查询的相关参数
   */
  detailBondResultAjax: function (url, allData) {
    var _this = this;
    _this.searchJSONP({
      type: "post",
      url: url,
      data: allData,
      timeout: 10000,
      successCallback: function (data) {
        var wstockData = data.result;
        var stockEleArr = "";
        if (wstockData != "" && wstockData != null) {
          $.each(wstockData, function (idx, item) {
            if (idx < 5) {
              var isUrlHttp = item.url
                ? /^https:|http:|\/\//i.test(item.url)
                : item.docURL
                ? /^https:|http:|\/\//i.test(item.docURL)
                : ture;
              stockEleArr +=
                '<li class="d-flex justify-content-between list-group-item">';
              stockEleArr += '<div class="search_listTitle">';
              if (!isUrlHttp) {
                var isWWW = item.url
                  ? /^www/i.test(item.url)
                  : item.docURL
                  ? /^www/i.test(item.docURL)
                  : false;
                if (isWWW) {
                  stockEleArr +=
                    '<a target="_blank"  href="' +
                    (item.url
                      ? "http://" + item.url
                      : item.docURL
                      ? "http://" + item.docURL
                      : "#") +
                    '">';
                } else {
                  stockEleArr +=
                    '<a target="_blank"  href="' +
                    (item.url ? item.url : item.docURL ? item.docURL : "#") +
                    '">';
                }
              } else {
                stockEleArr +=
                  '<a target="_blank"  href="' +
                  (item.url ? item.url : item.docURL ? item.docURL : "#") +
                  '">';
              }
              stockEleArr += item.title || item.docTitle;
              stockEleArr += "</a>";
              stockEleArr += "</div>";
              stockEleArr +=
                '<span class="text-nowrap new_date">' +
                (item.SSEDate
                  ? item.SSEDate
                  : item.createTime.substring(
                      0,
                      item.createTime.indexOf(" ")
                    )) +
                "</span>";
              stockEleArr += "</li>";
            }
            if (stockEleArr == "") {
              stockEleArr +=
                '<li class="d-flex justify-content-between list-group-item border-bottom-0">';
              stockEleArr += "暂无数据";
              stockEleArr += "</li>";
            }
            $(".search_rightList ul").html(stockEleArr);
          });
        } else {
          stockEleArr +=
            '<li class="d-flex justify-content-between list-group-item border-bottom-0">';
          stockEleArr += "暂无数据";
          stockEleArr += "</li>";
          $(".search_rightList ul").html(stockEleArr);
        }
      },
      errCallback: function () {
        stockEleArr +=
          '<li class="d-flex justify-content-between list-group-item border-bottom-0">';
        stockEleArr += "暂无数据";
        stockEleArr += "</li>";
        $(".search_rightList ul").html(stockEleArr);
      },
    });
  },

  //删掉默认tab失效栏目Id
  delRepeat: function (curr, parent) {
    var _this = this;
    var parentData = SSE_MENU_28[parent]; //获取当前栏目
    if (parentData) {
      //当前栏目存在
      var parentCoda = parentData.PARENTCODE; //获取父级CODE
      if (parentCoda == "0" || parentCoda == 0) return; //如果是0是有效结束循环
      if (parentCoda) {
        var ppData = SSE_MENU_28[parentCoda]; //获取父级栏目
        if (!ppData) {
          //父级栏目不存在删除
          delete _this.param.activeChnlIds[curr];
        } else {
          //父级栏目存在继续往上级循环
          _this.delRepeat(curr, ppData.PARENTCODE);
        }
      }
    } else {
      //当前栏目不存在移除
      delete _this.param.activeChnlIds[curr];
    }
  },
  //删掉其他tab失效栏目id
  setOtherTabCode: function () {
    var _this = this;
    //存储所有命中的栏目id
    var codeArr = _this.param.qwCodeStr ? _this.param.qwCodeStr.split(",") : [];
    var codeObj = {};
    for (var i = 0; i < codeArr.length; i++) {
      codeObj[codeArr[i]] = i;
    }
    _this.param.activeChnlIds = codeObj;
    //删掉失效的栏目id
    for (var i in _this.param.activeChnlIds) {
      _this.delRepeat(i, i);
    }
    //处理后的栏目id  --》 字符串 赋值给接口需要的参数
    var codeStr = "";
    for (var codeId in _this.param.activeChnlIds) {
      codeStr += codeId + ",";
    }
    codeStr =
      codeStr.substring(codeStr.length - 1) == ","
        ? codeStr.substring(0, codeStr.length - 1)
        : codeStr; //删掉最后一个多余的逗号
    if (!codeStr) {
      if (this.searchNums == "0") {
        _this.param.qwCodeStr = "";
      } else if (this.searchNums == "1") {
        //公告
        _this.param.qwCodeStr = _this.param.channelCode.announceId;
      } else if (this.searchNums == "5") {
        //监管
        _this.param.qwCodeStr = _this.param.channelCode.supervisionId;
      } else if (this.searchNums == "4") {
        //规则
        _this.param.qwCodeStr = _this.param.channelCode.ruleId;
      }
    }
    _this.param.qwCodeStr = codeStr;
    _this.getAllWordsResultNew(0);
  },
  //新建全文检索接口3333
  getAllWordsResultNew: function (pageIndex, v) {
    var _this = this;
    if (!_this.param.searchQueryWord)return;
    var paramsObj = _this.param;
    var nowNum = _this.searchNums + 1;
    var toPage = dynaGetData2022(".js_content0" + nowNum, pageIndex);
    if (isNaN(toPage)) {
      return;
    }
    $("#searchword").val(paramsObj.searchQueryWord);
    $(".valueClear").show();
    paramsObj.qwParam.keyword = _this.param.searchQueryWord;
    paramsObj.qwParam.spaceId = _this.param.qwParam.spaceId;
    var siteName = {
      3:"sse",
      45:"english",
      53:"etf",
      49:"training"
    };
    paramsObj.qwParam.siteName = siteName[_this.param.qwParam.spaceId];
    paramsObj.qwParam.keywordPosition =
      paramsObj.qwType != 2 ? "title" : "title,paper_content";
    paramsObj.qwParam.page = toPage - 1;
    paramsObj.qwParam.limit = "10";
    paramsObj.qwParam.publishTimeStart = paramsObj.searchTimeNew
      ? paramsObj.searchTimeNew.split("&&")[0] + " 00:00:00"
      : ""; //yyyy-MM-dd HH:mm:ss
    paramsObj.qwParam.publishTimeEnd = paramsObj.searchTimeNew
      ? paramsObj.searchTimeNew.split("&&")[1] + " 23:59:59"
      : "";
    paramsObj.qwParam.channelId = "10001"; //来源渠道id，生产官网10001
    paramsObj.qwParam.channelCode = _this.param.qwCodeStr;
    if (!paramsObj.qwParam.channelCode) {
      delete paramsObj.qwParam.channelCode;
    }
    //9527代表点击了分页后的查询
    if (v && v == 9527) {
      _this.param.qwParam.trackId && delete _this.param.qwParam.trackId;
    } else if (!v) {
      _this.param.qwParam.trackId = _this.getUuid(32);
    }
    $(".bottom_list").hide();
    _this.isHasList = false;

    //公告栏目支持多关键词搜索
    if(_this.searchNums == 1){
      paramsObj.qwParam.searchMode = 'preciseMulti';
    }

    _this.searchJSONP({
      url: SSE_QUERY_SEARCH_URL_2022 + _this.param.searchQueryUrl.qwjsNew,
      data: paramsObj.qwParam,
      type: "post",
      dataType: "jsonp",
      jsonp: "jsonCallBack",
      timeout: 20000,
      successCallback: function (res) {
        if (
          res &&
          res.data &&
          res.data.knowledgeList &&
          res.data.knowledgeList.length > 0 &&
          res.code === "0"
        ) {
          $(".js_content0" + nowNum + " .bottom_list ul").html("");
          $(".js_content0" + nowNum + " .bottom_list").show();

          //首页全部频道
          if (nowNum == 1) {
            _this.isHasList = true;
          }

          //公告栏目默认不显示筛选工具，搜到数据才显示,更换搜索词后要收起
          if (nowNum == 2) {
            $(".search-notice-tool-content").show();
          }

          var htm = "";
          $.each(res.data.knowledgeList, function (k, v) {
            htm += '<li class="list-group-item">';
            var sse_origin =
              location.protocol +
              "//" +
              SSE_SEARCH_RANGE.find(function (e) {
                return e.id == _this.param.qwParam.spaceId;
              }).URL; //不同搜索范围添加不同域名
            var _url =
              sse_origin +
              v.extend.find(function (e) {
                return e.name == "CURL";
              }).value;
            //非中文官网直接展示对应网站名，因为28full里没有这些网站的栏目
            var channel = {};
            var fileIcon = ""; //附件图标
            if (_this.param.qwParam.spaceId == SSE_SEARCH_RANGE[0].id) {
              var _CCHANNELCODE = v.extend.find(function (e) {
                return e.name == "CCHANNELCODE";
              }).value;

              var _PARENT_CURL = v.extend.find(function (e) {
                return e.name == "PARENT_CURL";
              }).value;

              var _PARENT_TITLE = v.extend.find(function (e) {
                return e.name == "PARENT_TITLE";
              }).value;

              var _FILETYPE = v.extend.find(function(e) {
                return e.name == "FILETYPE";
              }).value;

              var isAttachment = (_PARENT_CURL && _PARENT_TITLE) ? true : false;  //判断是否为附件
              if (isAttachment) {
                if (_FILETYPE === "docx" || _FILETYPE === "doc") {
                  fileIcon = "<img src='/xhtml/images/ui/icon-word-20.jpg'>";
                } else if (_FILETYPE === "pdf") {
                  fileIcon = "<img src='/xhtml/images/ui/icon-pdf-20.jpg'>";
                } else if (_FILETYPE === "wps") {
                  fileIcon = "<img src='/xhtml/images/ui/icon-wps-20.jpg'>";
                }
              }

              if (_CCHANNELCODE == '9860' || _CCHANNELCODE == '9862') {
                _CCHANNELCODE = '14911';//公开发行公司债券（含企业债券）公告
              }

              if (_CCHANNELCODE == '9865') {
                _CCHANNELCODE = '14912';//非公开发行公司债券（含企业债券）公告
              }
              
              //公告栏栏目标签与其他不一样
              if (_this.searchNums == 1) {
                _this.anouncementTag.forEach(function(arg) {
                  if(arg.channelId.indexOf(_CCHANNELCODE) > -1) {
                    channel.s = arg.name;
                    channel.u = arg.url;
                  }
                });
              } else {
                channel = _this.findChannel(_CCHANNELCODE, isAttachment, _PARENT_CURL);
              }
            } else {
              var childChannel = SSE_SEARCH_RANGE.find(function (e) {
                return e.id == _this.param.qwParam.spaceId;
              });
              channel = {
                s: childChannel.name,
                u: location.protocol + "//" + childChannel.URL,
              };
            }

            //监管来自文案替换
            if(_this.param.channelCode.supervisionId.indexOf(_CCHANNELCODE) > -1){
              channel.s = "上交所网站-监管";
            }

            //搜索命中的标题样式置为红色
            var rtitleTxtRp = v.title
              ? v.title.replace(/<em>(.*?)<\/em>/g, "<font color='#bc0007'>$1</font>")
              : "";

            //搜索命中的标题替换掉【】
            rtitleTxtRp = rtitleTxtRp ? rtitleTxtRp.replace(/^\[(.*?)\]\[(.*?)\]/,"<span class='red-back'>$1</span><span class='red-back'>$2</span>"): "";

            //搜索名字的正文
            v.rtfContent = _this.isCompatibleStr(v.rtfContent); //去除word特殊符号
            var rtfContent = v.rtfContent
              ? v.rtfContent.replace(/<em>(.*?)<\/em>/g, "$1")
              : "";
            var rtfContentRp = v.rtfContent
              ? v.rtfContent.replace(
                  /<em>(.*?)<\/em>/g,
                  "<font color='#bc0007'>$1</font>"
                )
              : "";
            var _content = rtfContent ? rtfContentRp || rtitleTxtRp : "";
            htm +=
              '<div class="bot_title"><a class="bot_title_a" href="' +
              _url +
              '" target="_blank"><i' +
              " documentId=" +
              v.documentId +
              " id=" +
              v.id +
              " " +
              ' style="font-style: normal;" onclick="clickPdf($(this))">' +
              fileIcon + ' ' + rtitleTxtRp +
              "</i></a>";
            htm += '<span class="new_date">';
            if(_this.searchNums == 1){
              htm +='<a class="anouncements-from-column" href="'+ channel.u+'" target="_blank">' + channel.s + "</a>";
            }
            htm += (v.createTime ? v.createTime.split(" ")[0] : "") + "</span>";
            htm +=  "</div>";

            //只搜标题时不展示内容
            if (_this.param.qwParam.keywordPosition != "title") {
              htm += '<div class="bot_summary">' + _content + "</div>";
            }

            if(_this.searchNums != 1){
              htm += "<div>来自 ：" + channel.s;
            }
            htm += "</div>";
            htm += "</li>";
          });
          var resPage = res.data.page;
          //公告防止接口执行过慢--标题内容切换时被覆盖
          $(".js_content0" + nowNum + " .bottom_list ul").html(htm);
          $(".js_content0" + nowNum + " .search_total").text(
            res.data.totalSize
          );
          $(".js_content0" + nowNum + " .search_start").text(
            parseInt(res.data.totalSize) ? resPage * res.data.limit + 1 : 0
          );
          $(".js_content0" + nowNum + " .search_end").text(
            parseInt(res.data.totalSize)
              ? resPage * res.data.limit + res.data.knowledgeList.length
              : 0
          );
          Page2022.navigation(
            ".js_content0" + nowNum + " .bottom_list .pagination-box",
            parseInt(res.data.totalPage),
            parseInt(res.data.totalSize),
            parseInt(resPage + 1),
            parseInt(res.data.limit),
            "sseSearch.getAllWordsResultNew",
            9527,
            bind_name
          );
        } else {
          //公告栏无结果并且没有筛选条件时隐藏筛选框
          if (nowNum == 2 && $(".search-notice-tool-content .big_active").length == 0 && $(".search-notice-tool-content .iconcirclecheckfull").length == 0 ) {
            $(".search-notice-tool-content").hide();
          }
          if (_this.searchNums == 0) {
            _this.searchNullCount += 1;
            if (
              _this.searchNullCount == 2 ||
              _this.param.qwParam.spaceId != SSE_SEARCH_RANGE[0].id
            ) {
              setTimeout(function () {
                $(".bottom_list").show();//正文显示时机后移修复搜索有结果时切换其他搜索条件无结果时页面闪烁问题
                _this.emptyUl(nowNum, _this.searchNums);
              }, 500);
            } else {
              $(".bottom_list").hide();
            }
          } else {
            setTimeout(function () {
              $(".bottom_list").show();
              _this.emptyUl(nowNum);
              $(".js_content0" + nowNum + " .bottom_list .pagination-box").html(
                ""
              );
              $(".js_content0" + nowNum + " .search_total").text("");
              if (
                $(".js_content01 .search_columns").css("display") == "block" &&
                $(".js_content01 .js_companyDetail").css("display") ==
                  "block" &&
                nowNum == 1
              ) {
                $(".js_content01 .bottom_list").hide();
              } else {
                $(".js_content01 .bottom_list").show();
              }
            }, 500);
          }
        }
      },
      errCallback: function () {
        $(".bottom_list").show();
        if (nowNum == 2) {
          $(".search-notice-tool-content").hide();
        }
        if (_this.searchNums == 0) {
          _this.searchNullCount += 1;
          if (_this.searchNullCount == 2) {
            _this.emptyUl(nowNum, _this.searchNums);
          }
        } else {
          var timer = setTimeout(function () {
            _this.emptyUl(nowNum);
            $(".js_content0" + nowNum + " .bottom_list .pagination-box").html(
              ""
            );
            if (
              $(".search_columns").attr("display") == "block" &&
              $(".js_companyDetail").attr("display") == "block" &&
              nowNum == 1
            ) {
              $(".js_content01 .bottom_list").hide();
            } else {
              $(".js_content01 .bottom_list").show();
            }
            clearTimeout(timer);
          }, 500);
        }
      },
    });
  },
  /**全文检索文章埋点,外部指向 */
  getSearchTitleClick: function (paramObj, that) {
    that.searchJSONP({
      url:
        SSE_QUERY_SEARCH_GETCLICK_URL_2022 +
        that.param.searchQueryUrl.searchTitleClickUrl,
      data: paramObj,
      type: "post",
      dataType: "jsonp",
      jsonp: "jsonCallBack",
      timeout: 20000,
      successCallback: function (res) {
        //todo
      },
      errCallback: function () {
        //todo
      },
    });
  },

  //根据28full获取栏目名称
  findChannel: function (_CCHANNELCODE, isAttachment, _PARENT_CURL) {
    let o = {}, s = [];
    if (!isAttachment) {
      if (SSE_MENU_28[_CCHANNELCODE]) {
        let c = SSE_MENU_28[_CCHANNELCODE];
        o.u = location.protocol + "//" + SSE_MENU_28[0].URL + c.URL;
        s.unshift(c.CHNLNAME);
        while (c.PARENTCODE) {
          c = SSE_MENU_28[c.PARENTCODE];
          if (c) {
            if (c.PARENTCODE === "") {
              s.unshift("上交所网站");
            } else {
              if (c.DISPLAY == 1) {
                s.unshift(c.CHNLNAME);
              }
            }
          } else {
            c = {};
            s.unshift("上交所网站");
          }
        }
      } else {
        s.unshift("上交所网站");
        o.u = location.protocol + "//" + SSE_MENU_28[0].URL;
      }
      o.s = s.join("-");
    } else {
      o.s = '<a href="' + window.location.protocol + '//' + window.location.host + _PARENT_CURL + '" target="_blank">' + 
        window.location.protocol + '//' + window.location.host + _PARENT_CURL + '</a>';
      o.u = location.protocol + "//" + SSE_MENU_28[0].URL;
    }
    return o;
  },

  //获取数据列表
  getDataList: function () {
    var _this = this;
    _this.matchLength = 0;
    $(".js_companyDetail").parent().hide(); //默认表格，推荐栏目隐藏有数据再展示
    $(".js_companyDetail").hide();
    var noHtm =
      '<div class="data_noDaTa">没有找到您要找的内容，您可以试试其他搜索词，谢谢！</div>';
    var filterSearchQueryWord = _this.param.searchQueryWord.replace(/[\*\(\)\[\]]/g,'');
    if (!filterSearchQueryWord){
      if (_this.searchNums == 0) {
        _this.searchNullCount += 1;
        if (_this.searchNullCount == 2) {
          _this.emptyUl(1, _this.searchNums);
        }
      } else {
        $(".js_dataTable").html(noHtm);
      }
      return;
    }
    _this.searchJSONP({
      url: sseQueryURL + _this.param.searchQueryUrl.dataUrl,
      data: {
        question: filterSearchQueryWord,
        searchName: "dataSearchNew",
      },
      timeout: 20000,
      successCallback: function (res) {
        if (res && res.data) {
          var listData = JSON.parse(res.data);
          var list = listData.answer_list;
          var htm = "";
          if (list && list.length > 0) {
            var nums = 0;
            $.each(list, function (k, v) {
              var anList = v.answer;
              var highList = v.highlights;
              if (
                (_this.searchNums == 0 && nums < 0) ||
                _this.searchNums == 2
              ) {
                if (anList && anList.length > 0) {
                  nums++;
                  if (_this.searchNums == 0) {
                    htm +=
                      '<div class="title_lev3' +
                      (k != 0 ? " first_title" : "") +
                      '">' +
                      v.intention_name +
                      "</div>";
                    if (!_this.isHasList) {
                      //如果检索列表为空隐藏
                      $(".js_content01 .bottom_list").hide();
                    } else {
                      $(".js_content01 .bottom_list").show();
                    }
                  } else {
                    htm +=
                      '<div class="title_lev3 first_title">' +
                      v.intention_name +
                      "</div>";
                  }
                  htm += '<div class="table-responsive search_dataTable">';
                  htm += '<table class="table table-hover">';
                  htm += "<thead>";
                  var _tr1 = "<tr>";
                  var _tr2 = "<tr>";
                  var filterName = {};
                  var excludeCol = {
                    fd23c57036643ab6835f0a9bd88abfab: "1",
                    bb4bbf72db3c518e8e7f5de4199d2d79: "1",
                    "7d801014a1351fca0a39c5ded4fd7d06": "1",
                    ca70e6378a4b7e87bfad2d916576e27e: "1",
                  };
                  var referCol = {
                    "42bd22a177899c5b1d4d4ab008e58a91":
                      "fd23c57036643ab6835f0a9bd88abfab",
                    "8acff848823f9ee6786c5cef3a44b165":
                      "bb4bbf72db3c518e8e7f5de4199d2d79",
                    "63c0797c74bd3a71f0390fe5431d2c15":
                      "7d801014a1351fca0a39c5ded4fd7d06",
                    f4db720b93ea46c95c44227a2ce173e2:
                      "ca70e6378a4b7e87bfad2d916576e27e",
                  };
                  $.each(anList, function (key, val) {
                    var _th = "";
                    var _td = "";
                    var n = 0,
                      m = 0; //截取9列数据所有的记录参数
                    if (key == 0) {
                      for (var name in val) {
                        filterName[name] = _this.filterAlign(val[name]);
                        if (n < 9) {
                          var arr = name.split(".");
                          if (arr[0] in excludeCol) {
                            excludeCol[arr[0]] = name;
                            continue;
                          }
                          var isHight = false; //是否高亮
                          $.each(highList, function (h, high) {
                            var hightArr = high.split(".");
                            if (arr[1] == hightArr[1]) {
                              isHight = true;
                            }
                          });
                          _th +=
                            '<th class="' +
                            filterName[name] +
                            (isHight
                              ? ' redColor" style="color:#bc0007;'
                              : "") +
                            '">' +
                            (arr[1] ? arr[1] : "-") +
                            "</th>";
                        }
                        n++;
                      }
                      _tr1 += _th + "</tr>";
                    }
                    for (var name in val) {
                      var arr = name.split(".");
                      if (arr[0] in excludeCol) {
                        continue;
                      }

                      if (m < 9) {
                        if (
                          arr[0] in referCol &&
                          !(
                            _this.getObjValues(val).includes("监管工作函") &&
                            Object.keys(val)[
                              _this.getObjValues(val).indexOf("监管工作函")
                            ].split(".")[0] ==
                              "f534a48893265f56138563be7d1b7df6"
                          ) &&
                          !(
                            _this
                              .getObjValues(val)
                              .includes("规范运作建议书") &&
                            Object.keys(val)[
                              _this.getObjValues(val).indexOf("规范运作建议书")
                            ].split(".")[0] ==
                              "f534a48893265f56138563be7d1b7df6"
                          )
                        ) {
                          var hrefVal =
                            val[excludeCol[referCol[arr[0]]]] &&
                            val[excludeCol[referCol[arr[0]]]] != "None" &&
                            val[excludeCol[referCol[arr[0]]]] != "null"
                              ? val[excludeCol[referCol[arr[0]]]]
                              : "#";
                          var aStr = "";
                          if (hrefVal == "#") {
                            aStr +=
                              val[name] &&
                              val[name] != "None" &&
                              val[name] != "null"
                                ? val[name]
                                : "-";
                          } else {
                            if (
                              arr[0] == "63c0797c74bd3a71f0390fe5431d2c15" ||
                              arr[0] == "f4db720b93ea46c95c44227a2ce173e2"
                            ) {
                              if (!hrefVal.startsWith("http")) {
                                if (hrefVal.startsWith("www")) {
                                  hrefVal = "//" + hrefVal;
                                } else {
                                  hrefVal = "//www.sse.com.cn" + hrefVal;
                                }
                              }
                            } else {
                              hrefVal = "//static.sse.com.cn" + hrefVal;
                            }
                            aStr +=
                              '<a href="' +
                              hrefVal +
                              '" target="_blank">' +
                              (val[name] &&
                              val[name] != "None" &&
                              val[name] != "null"
                                ? val[name]
                                : "-") +
                              "</a>";
                          }

                          _td +=
                            '<td class="text-nowrap ' +
                            filterName[name] +
                            '" title="' +
                            (val[name] &&
                            val[name] != "None" &&
                            val[name] != "null"
                              ? val[name]
                              : "-") +
                            '">' +
                            aStr +
                            "</td>";
                        } else {
                          _td +=
                            '<td class="text-nowrap ' +
                            filterName[name] +
                            '" title="' +
                            (val[name] &&
                            val[name] != "None" &&
                            val[name] != "null"
                              ? val[name]
                              : "-") +
                            '">' +
                            (val[name] &&
                            val[name] != "None" &&
                            val[name] != "null"
                              ? val[name]
                              : "-") +
                            "</td>";
                        }
                      }
                      m++;
                    }
                    _tr2 += _td + "</tr>";
                  });
                  htm += _tr1;
                  htm += "</thead>";
                  htm += "<tbody>" + _tr2 + "</tbody>";
                  htm += "</table></div>";
                }
              }
            });
            $(".js_companyDetail").show();
            $(".js_companyDetail").parent().show();
            $(".js_dataTable").html(htm);
            $(".js_companyDetail").html(htm);
            if (_this.searchNums == 0) {
                _this.searchNullCount += 1;
                if (_this.searchNullCount == 2) {
                  _this.emptyUl(1, _this.searchNums);
                }
            } else if(_this.searchNums == 2){
              if (list[0].answer && list[0].answer.length <= 0) {
                $(".js_dataTable").html(noHtm);
              }
            }
          } else {
            if (_this.searchNums == 0) {
              _this.searchNullCount += 1;
              if (_this.searchNullCount == 2) {
                _this.emptyUl(1, _this.searchNums);
              }
            } else {
              $(".js_dataTable").html(noHtm);
            }
          }
        } else {
          if (_this.searchNums == 0) {
            _this.searchNullCount += 1;
            if (_this.searchNullCount == 2) {
              _this.emptyUl(1, _this.searchNums);
            }
          } else {
            $(".js_dataTable").html(noHtm);
          }
        }
      },
      errCallback: function () {
        if (_this.searchNums == 0) {
          _this.searchNullCount += 1;
          if (_this.searchNullCount == 2) {
            _this.emptyUl(1, _this.searchNums);
          }
        } else {
          $(".js_dataTable").html(noHtm);
        }
      },
    });
  },
  //获取问答数据
  getFAQ: function () {
    var _this = this;
    var filterSearchQueryWord = _this.param.searchQueryWord.replace(/[\*\(\)\[\]]/g,'');
    if (!filterSearchQueryWord){
      return;
    }
    var noHtm =
      '<div class="data_noDaTa">没有找到您要找的内容，您可以试试其他搜索词，谢谢！</div>';
    _this.searchJSONP({
      url: sseQueryURL + _this.param.searchQueryUrl.faq,
      data: {
        keyword: filterSearchQueryWord,
        spaceId: 3,
      },
      timeout: 20000,
      successCallback: function (res) {
        if (res && res.data && res.data.length) {
          $("#js_faq_content").attr("class", "col-md-12");
          $("#js_faq_try").hide();
          $(".faq-title").show();
          var faqHtml = '<ul class="list-group list-group-flush faq-ul">';
          $.each(res.data, function (index, arg) {
            faqHtml += '<li class="list-group-item">';
            faqHtml += '<div class="bot_title">' + arg.stq + "</div>";
            faqHtml +=
              '<div class="bot_summary">' +
              arg.answer.replace(/\\(n)/, "") +
              "</div></li>";
          });
          faqHtml += "</ul>";
          $(".js_dataTable").html(faqHtml);
        } else {
          //设置试试搜一搜
          $("#js_faq_content").attr("class", "col-md-10");
          $("#js_faq_try").show();
          $(".js_dataTable").html(noHtm);
          $(".faq-title").hide();
        }
      },
      errCallback: function () {
        //设置试试搜一搜
        $("#js_faq_content").attr("class", "col-md-10");
        $("#js_faq_try").show();
        $(".js_dataTable").html(noHtm);
        $(".faq-title").hide();
      },
    });
  },
  //问答频道获取想要看的栏目
  getFaqColumn: function () {
    var _this = this;
    _this.matchLength = 0;
    $(".js_defaultColumn").html(""); //清空栏目推荐
    $(".js_columnCon").hide();
    $(".js_columnCon").html("");
    $(".js_siteColumn").hide();

    //调用数据接口获取一部分栏目，再调用想要看的栏目接口
    _this.searchJSONP({
      url: sseQueryURL + _this.param.searchQueryUrl.dataUrl,
      data: {
        question: _this.param.searchQueryWord,
        searchName: "dataSearchNew",
      },
      timeout: 20000,
      successCallback: function (res) {
        if (res && res.data) {
          var listData = JSON.parse(res.data);
          //想看的栏目，问答频道展示与数据频道一致，即只有想看的栏目
          var match = listData.matchedList;
          if (match.length > 0) {
            $(".js_content07 .js_columnCon_back").addClass("full-back"); //问答频道下站点栏目底色显示隐藏逻辑
            _this.matchLength = match.length;
            var colum = "";
            $.each(match, function (k, v) {
              _this.hrefArr.push(v.columnUrl);
              colum +=
                '<span><a href="' +
                v.columnUrl +
                '" target="_blank">' +
                v.columnName +
                "</a></span>";
            });
            $(".js_content07 .js_defaultColumn").html(colum);
            $(".search_columns").show();
          } else {
            $(".js_content07 .js_columnCon_back").removeClass("full-back"); //问答频道下站点栏目底色显示隐藏逻辑
          }
        }
      },
    });
  },
  // 高亮表格样式
  filterAlign: function (value) {
    var pattern =
      /[\u4e00-\u9fa5]+|^\d{6}$|^\d{4}-?(?:0[1-9]|1[0-2])-?(?:0[1-9]|[12][0-9]|3[01])$/g;
    if (value == "-") {
      return "text-center";
    } else {
      if (pattern.test(value)) {
        return "text-center";
      } else {
        return "text-right";
      }
    }
  },
  //重新搜索时初始化页面
  initHtml: function (indexNum,triggerEvent) {
    var _this = this;
    //参数
    _this.searchNums = Number(indexNum);
    _this.param.searchTime = "";
    //tab切换 页面对应部分初始化
    //检索接口参数
    _this.param.qwCodeStr = "";
    _this.param.qwParam = {
      page: 1,
      limit: 10,
      publishTimeEnd: "",
      publishTimeStart: "",
      orderByDirection: "DESC",
      orderByKey: "score",
      searchMode: "fuzzy",
      spaceId: SSE_SEARCH_RANGE[0].id, //默认搜索范围是官网，除全部搜索外其余tab均为搜索官网
    };
    //初始化公告栏目筛选项选中状态
    _this.anouncementsFiterItem = [
      {
        type: "time",
        text: "",
        isSelected: false
      },{
        type: "anounce",
        text: "主板股票",
        isSelected: false
      },{
        type: "anounce",
        text: "科创板股票",
        isSelected: false
      },{
        type: "anounce",
        text: "债券",
        isSelected: false
      },{
        type: "anounce",
        text: "基金",
        isSelected: false
      }
    ];
    _this.renderAnoReset();

    _this.param.searchTimeNew = "";

    //标题和内容的标识参数 1标题2标题+内容
    if (indexNum == 3) {
      _this.param.qwType = 2;
      $("#search-title").html(" 搜标题和正文 ");
    } else if (indexNum == 1) {
      if(!(triggerEvent&&triggerEvent == 'operateReSearch')){
        _this.param.qwType = 1;
        $("#search-title").html(" 搜标题 ");
      }
      _this.param.qwParam.orderByKey = "create_time";
      _this.param.qwParam.searchMode = "precise";//公告栏只有精确搜索
    } else {
      _this.param.qwType = 2;
      $("#search-title").html(" 搜标题和正文 ");
    }
    _this.isTitle = true; //公告部分是标题还是内容

    //公共部分
    $(".search_option").html(""); //筛选
    $(".pagination-box").html(""); //分页清空
    if (_this.param.searchQueryWord) {
      $(".bottom_list ul").html(""); //列表
    }
    $(".search_columns").hide(); //想看的栏目
    //总条数从几条到几条
    $(".search_total").text(0);
    $(".search_start").text(0);
    $(".search_end").text(0);

    //从监管往后的排序选中状态
    if (indexNum > 1) {
      $(".js_content0" + (indexNum + 1) + " .sort_condition .tool_title")
        .removeClass("titleSelected")
        .eq(1)
        .addClass("titleSelected");
      $(".js_content0" + (indexNum + 1) + " .sort_condition .iconcircle")
        .removeClass("iconcirclecheckfull")
        .eq(1)
        .addClass("iconcirclecheckfull");
    }

    //默认页面
    if (indexNum == 0) {
      //时间清空
      $(".js_defaultDate").val("");
      //默认标题搜索，时间排序
      $(".js_content01 .tool_one")
        .find(".titleSelected")
        .removeClass("titleSelected");
      $(".js_content01 .tool_one")
        .find(".iconcirclecheckfull")
        .removeClass("iconcirclecheckfull");
      $(".js_content01 .sort_condition")
        .find(".tool_title")
        .eq(1)
        .addClass("titleSelected");
      $(".js_content01 .sort_condition")
        .find(".tool_title")
        .eq(1)
        .find(".iconcircle")
        .addClass("iconcirclecheckfull");

      //搜索范围赋值，url带参时会执行此处代码但是下拉框未初始化
      if (!$(".js_searchScope .selectpicker").selectpicker) {
        var scopeHtm = "";
        SSE_SEARCH_RANGE.forEach(function (arg) {
          scopeHtm +=
            '<option value="' + arg.id + '">' + arg.name + "</option>";
        });
        //调用bootstrap-select
        bootstrapSelect({
          method: function () {
            $(".js_searchScope .selectpicker")
              .html(scopeHtm)
              .selectpicker("refresh")
              .selectpicker("render");
            //市场类型改变调用参数
            $(".js_searchScope .selectpicker").on(
              "changed.bs.select",
              function (e, clickedIndex, isSelected, previousValue) {
                _this.param.qwParam.spaceId = $(
                  ".js_searchScope .selectpicker"
                ).val();
                if (_this.param.qwParam.spaceId == SSE_SEARCH_RANGE[0].id) {
                  _this.initFunction();
                } else {
                  _this.getAllWordsResultNew(0);
                }
              }
            );
          },
        });
      } else {
        //搜索范围select回到初始状态
        $(".js_searchScope .selectpicker").get(0).selectedIndex = 0;
        $(".js_searchScope .selectpicker")
          .selectpicker("refresh")
          .selectpicker("render");
        _this.param.qwParam.spaceId = SSE_SEARCH_RANGE[0].id;
      }

      $(".js_chartCon").hide();
      $("#econtent").html("");
      $(".js_companyDetail .table").html("");
    } else if (indexNum == 1) {
      //默认标题搜索，时间排序
      $(".search-notice-tool-content").hide();//公告筛选工具默认隐藏
      $(".js_content02")
        .find(".titleSelected")
        .removeClass("titleSelected");
      $(".js_content02")
        .find(".iconcirclecheckfull")
        .removeClass("iconcirclecheckfull");
      $(".js_content02")
        .find(".big_active")
        .removeClass("big_active");
      $(".js_ano_time_start").html("开始时间");
      $(".js_ano_time_end").html("结束时间");
    } else if (indexNum == 4 || indexNum == 5) {
      $(".js_content0" + (indexNum + 1) + " .sse_input").val("");
      $(
        ".js_content0" + (indexNum + 1) + " .search_typeCon .big_active"
      ).removeClass("big_active");
      $(
        ".js_content0" +
          (indexNum + 1) +
          " .search_typeCon .iconcirclecheckfull"
      ).removeClass("iconcirclecheckfull");
      $(
        ".js_content0" + (indexNum + 1) + " .js_supervisionOption span"
      ).remove();
    } else if (indexNum == 3) {
      //新闻
      $(".js_content0" + (indexNum + 1) + " .sse_input").val("");
      $(
        ".js_content0" + (indexNum + 1) + " .search_typeCon .big_active"
      ).removeClass("big_active");
      $(
        ".js_content0" +
          (indexNum + 1) +
          " .search_typeCon .iconcirclecheckfull"
      ).removeClass("iconcirclecheckfull");
    }
    //检索参数channelCode初始化
    if (indexNum == 1) {
      //公告
      _this.param.qwCodeStr = _this.param.channelCode.announceId;
    } else if (indexNum == 5) {
      //监管
      _this.param.qwCodeStr = _this.param.channelCode.supervisionId;
    } else if (indexNum == 4) {
      //规则
      _this.param.qwCodeStr = _this.param.channelCode.ruleId;
    } else if (indexNum == 3) {
      //新闻
      _this.param.qwCodeStr = _this.param.channelCode.newsId;
    }
    if (indexNum == 0) {
      //默认tab
      _this.param.qwCodeStr = "";
    } else if ([4, 5].indexOf(indexNum) > -1) {
      _this.setOtherTabCode(); //规则、监管tab删掉失效栏目id
    }
  },

  /**
   * @author JackCHEN
   * @methods { getFundLink}  处理基金类型跳转链接
   * @version 创建时间：${date} ${2023/06/08}
   * @param { Object }  obj  传入的code相关的对象，包含code对应的简称和类型
   */
  getFundLink: function (obj) {
    if (obj.codeType.bigCodeType == "CB") {
      return (
        'target="_blank" href="/assortment/fund/list/reits/basic/index.shtml?FUNDID=' +
        obj.code +
        '"'
      );
    }
    switch (obj.codeType.smallCodeType) {
      case "EBS":
        return (
          'target="_blank" href="/assortment/fund/list/etfinfo/basic/index.shtml?FUNDID=' +
          obj.code +
          '"'
        );
      case "LOF":
        return (
          'target="_blank" href="/assortment/fund/list/lofinfo/basic/index.shtml?FUNDID=' +
          obj.code +
          '"'
        );
      default:
        return "javascript:void(0)";
    }
  },
  //公告设置全文检索channelCode
  setAnoParam: function () {
    var _this = this;

    //设置公告类型参数
    var anoCode = "";

    $(".js_anouncements_type .big_title").each(function () {
      var isHas = $(this).hasClass("big_active");
      if (isHas) {
        var name = $(this).attr("name");
        anoCode += _this.param.anoCode[name] + ",";
      }
    });

    _this.param.qwCodeStr = anoCode
      ? anoCode.replace(/\,$/,'')
      : _this.param.channelCode.announceId;
    _this.getAllWordsResultNew(0);
  },
  //规则设置全文检索channelCode
  setRuleParam: function () {
    var _this = this;
    var typeNum = $(".rule_type .big_title").length;
    var onNum = $(".rule_type .big_active").length;
    //设置规则类型参数
    var rCode = "";
    var spanStr = "";
    $(".rule_type .big_title").each(function () {
      var isHas = $(this).hasClass("big_active");
      if (isHas) {
        var txt = $(this).text();
        var name = $(this).attr("name");
        rCode += _this.param.ruleCode[name] + ",";
        spanStr +=
          '<span  name="' +
          name +
          '">' +
          txt +
          '<i class="bi-x-circle-fill"></i></span>';
        //gio全文搜索规则频道下类型选择内容--sseSearchFuncClick
        try {
          gdp("track", "sseSearchFuncClick", {
            sseSearchRuleType_var1: txt,
          });
        } catch (error) {}
      }
    });
    $(".js_ruleOption").html(spanStr);
    _this.param.qwCodeStr = rCode ? rCode : _this.param.channelCode.ruleId;
    _this.setOtherTabCode(); //处理失效栏目
  },
  //内容--加载日历插件
  setWordTime: function (obj, icon) {
    var _this = this;
    //加载日历插件
    laydate({
      elem: obj,
      eventElem: icon,
      theme: "#b50005",
      format: "yyyy/MM/dd",
      range: true,
      value: dateMaxLimit2022(1),
      isInitValue: false,
      trigger: "click",
      btns: ["clear", "confirm"],
      extrabtns: [
        { id: "today", text: "今日", range: latestType("today") },
        {
          id: "tomorrow",
          text: "明日",
          range: latestType("tomorrow"),
        },
        {
          id: "latestWeek",
          text: "近一周",
          range: latestType("week"),
        },
        {
          id: "latestMonth",
          text: "近一月",
          range: latestType("monthOne"),
        },
        {
          id: "latestYear",
          text: "近一年",
          range: latestType("year"),
        },
      ],
      done: function (value, date, endDate) {
        setTimeout(function () {
          var _value = $(obj).val(); //日期插件返回参数有问题，改成直接取输入框日期
          $(obj).attr("data-value", _value);
          _this.param.searchTimeNew = _value
            .replace(/\//g, "-")
            .replace(" - ", "&&");
          var timer = setTimeout(function () {
            _this.getAllWordsResultNew(0);
            _this.searchNullCount = 1;
            clearTimeout(timer);
          }, 0);
        }, 500);
      },
    });
  },
  //公告栏目--加载日历插件
  setAnoTime: function (obj, icon) {
    var _this = this;
    //加载日历插件
    laydate({
      elem: obj,
      eventElem: icon,
      theme: "#b50005",
      format: "yyyy/MM/dd",
      range: true,
      value: dateMaxLimit2022(1),
      isInitValue: false,
      trigger: "click",
      btns: ["clear", "confirm"],
      done: function (value, date, endDate) {
        setTimeout(function () {
          var _value = $(obj).val(); //日期插件返回参数有问题，改成直接取输入框日期
          $(obj).attr("data-value", _value);
          _this.param.searchTimeNew = _value
            .replace(/\//g, "-")
            .replace(" - ", "&&");
          if(_value){
            $(".js_ano_time_start").html(_this.param.searchTimeNew.split("&&")[0]);
            $(".js_ano_time_end").html(_this.param.searchTimeNew.split("&&")[1]);

            //公告栏日期选择选项改为选中自定义
            $(".js_anouncements_time .iconcircle").removeClass("iconcirclecheckfull");
            $(".js_anouncements_time .big_title").removeClass("big_active");
            $(".js_anouncements_time .big_title").eq(0).find(".iconcircle").addClass("iconcirclecheckfull");
            $(".js_anouncements_time .big_title").eq(0).addClass("big_active");
            _this.anouncementsFiterItem[0].isSelected = true;
            _this.anouncementsFiterItem[0].text = _value.replace(/\//g, "-");
            _this.renderAnoReset();
          }else{
            //点击清空
            $(".js_anouncements_time .iconcircle").removeClass("iconcirclecheckfull");
            $(".js_anouncements_time .big_title").removeClass("big_active");
            $(".js_ano_time_start").html("开始时间");
            $(".js_ano_time_end").html("结束时间");
            _this.anouncementsFiterItem[0].isSelected = false;
            _this.anouncementsFiterItem[0].text = '';
            _this.renderAnoReset();
          }
          var timer = setTimeout(function () {
            _this.getAllWordsResultNew(0);
            clearTimeout(timer);
          }, 0);
        }, 500);
      },
    });
  },
  //日历绑定
  getDateInput: function () {
    this.setWordTime(".js_defaultDate", ".date_input_icon");
    this.setAnoTime(".js_searchContent01", ".date_input_icon01");
    this.setWordTime(".js_ruleDate", ".date_input_icon04");
    this.setWordTime(".js_supervisionDate", ".date_input_icon05");
    this.setWordTime(".js_newsDate", ".date_input_icon06");
    //公告绑定时间
  },
  // 试着搜一搜 随机取10个
  filterHis: function () {
    var _this = this;
    var randNums = _this.getRandmNum(10, _this.allRecomendItems.length, []);
    var htm = "";
    for (var i = 0; i < randNums.length; i++) {
      htm += "<li>";
      htm +=
        "<b>" +
        (i + 1) +
        ".</b><span>" +
        _this.allRecomendItems[randNums[i]] +
        "</span>";
      htm += "</li>";
    }
    $(".try_list").html(htm);
  },
  //随机抽取几个数据
  getRandmNum: function (_size, len, _data) {
    var _this = this;
    var _num = parseInt(Math.random() * len);
    if (_data.length < _size) {
      if (_data.indexOf(_num) == -1) {
        _data.push(_num);
      }
      return _this.getRandmNum(_size, len, _data);
    } else {
      return _data;
    }
  },
  getOptionData: function () {
    var _this = this;
    var randNums = _this.getRandmNum(8, _this.optionData.length - 1, []);
    var optionDatas = [];
    for (var i = 0; i < randNums.length; i++) {
      optionDatas.push(_this.optionData[randNums[i]].name);
    }
    return optionDatas.join(",");
  },
  //清除词云图定时
  closeDrawer: function () {
    var _this = this;
    clearInterval(_this.wordcloudInterval);
  },
  //画词云图
  showWordcloud: function () {
    var _this = this;
    var dataStr = _this.getOptionData(); //随机获取八个数据
    require(["wordcloud"], function () {
      var data = dataStr.split(/[,\. ]+/g).reduce(function (arr, word) {
        var obj = arr.find(function (obj) {
          return obj.name === word;
        });
        if (obj) {
          obj.weight = Math.floor(Math.random() * 30 + 14);
        } else {
          obj = {
            name: word,
            weight: Math.floor(Math.random() * 30 + 14),
          };
          arr.push(obj);
        }
        return arr;
      }, []);
      var wordCloudID = "wordcloud" + _this.searchNums;
      Highcharts.chart(wordCloudID, {
        tooltip: {
          enabled: false,
        },
        chart: {
          height: 200,
        },
        colors: ["rgb(64, 158, 255)"],
        series: [
          {
            type: "wordcloud",
            data: data,
            style: {
              fontWeight: "500",
            },
            rotation: {
              from: -90,
              to: 90,
              orientations: 3,
            },
            cursor: "pointer",
            style: {
              fontWeight: 500,
            },
            events: {
              click: function (e) {
                var name = e.point.options.name;
                _this.closeDrawer(); //清除定时器
                _this.showWordcloud(); //加载词云图
                _this.wordcloudInterval = setInterval(function () {
                  _this.showWordcloud();
                }, 10000); //定时刷新
                if (_this.param.searchQueryWord != name) {
                  _this.param.searchQueryWord = name;
                  _this.searchInit(name);
                }
              },
            },
          },
        ],
        credits: {
          enabled: false,
        },
        title: {
          text: "",
        },
      });
    });
  },
  emptyUl: function (nowNum, searchNums) {
    var noHtm =
      '<li class="data_noDaTa">没有找到您要找的内容，您可以试试其他搜索词，谢谢！</li>';
    $(".js_content0" + nowNum + " .bottom_list .list-group").html(noHtm);
    $(".js_content0" + nowNum + " .bottom_list .pagination-box").html("");
    $(".js_content0" + nowNum + " .search_total").text(0);
    $(".js_content0" + nowNum + " .search_start").text(0);
    $(".js_content0" + nowNum + " .search_end").text(0);
    if (searchNums == 0) {
      $(".js_content0" + nowNum + " .bottom_list .pagination-box").html("");
      if (
        $(".js_content01 .search_columns").css("display") == "block" &&
        $(".js_content01 .js_companyDetail").css("display") == "block" &&
        nowNum == 1
      ) {
        $(".js_content01 .bottom_list").hide();
      } else {
        $(".js_content01 .bottom_list").show();
      }
    }
  },
  //免责声明弹框
  disclaimer: function (params) {
    var _this = this;
    $(".modal").on("show.bs.modal", function () {
      var modal = $(this);
      if (_this.isModal) {
        $(".modal-dialog").addClass("disclaimer_maxWidth");
        modal.find(".modal-body").html(params.text);
      }
    });
    $(".modal").on("hidden.bs.modal", function () {
      $(".modal-dialog").removeClass("disclaimer_maxWidth");
      $(".modal-body").html("");
      _this.isModal = false;
    });
    $(".modal").modal();
  },
  //jsonp超时处理
  searchJSONP: function (obj) {
    var jsonpCallback =
      "jsonpCallback" + Math.floor(Math.random() * (100000000 + 1));
    requestNum++;
    showLoading();
    $.ajax({
      type: obj.type ? obj.type : "post",
      url: obj.url,
      data: obj.data,
      dataType: obj.dataType ? obj.dataType : "jsonp",
      jsonp: obj.jsonp ? obj.jsonp : "jsonCallBack",
      cache: false,
      timeout: obj.timeout,
      jsonpCallback: jsonpCallback,
      contentType: "application/x-www-form-urlencoded; charset=UTF-8",
      success: obj.successCallback,
      error: obj.errCallback,
      complete: function (XMLHttpRequest, status) {
        requestNum--;
        if (requestNum == 0) {
          hideLoading();
          $(".table-responsive").append(
            "<style>.table-responsive::-webkit-scrollbar{ height:10px }</style>"
          );
        }
      },
    });
  },
  //词云图兼容ie
  setPolyfill: function () {
    if (!Array.prototype.find) {
      Object.defineProperty(Array.prototype, "find", {
        value: function (predicate) {
          // 1. Let O be ? ToObject(this value).
          if (this == null) {
            throw new TypeError('"this" is null or not defined');
          }

          var o = Object(this);

          // 2. Let len be ? ToLength(? Get(O, "length")).
          var len = o.length >>> 0;

          // 3. If IsCallable(predicate) is false, throw a TypeError exception.
          if (typeof predicate !== "function") {
            throw new TypeError("predicate must be a function");
          }

          // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
          var thisArg = arguments[1];

          // 5. Let k be 0.
          var k = 0;

          // 6. Repeat, while k < len
          while (k < len) {
            // a. Let Pk be ! ToString(k).
            // b. Let kValue be ? Get(O, Pk).
            // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
            // d. If testResult is true, return kValue.
            var kValue = o[k];
            if (predicate.call(thisArg, kValue, k, o)) {
              return kValue;
            }
            // e. Increase k by 1.
            k++;
          }

          // 7. Return undefined.
          return undefined;
        },
      });
    }
    if (!Array.prototype.reduce) {
      Object.defineProperty(Array.prototype, "reduce", {
        value: function (callback /*, initialValue*/) {
          if (this === null) {
            throw new TypeError(
              "Array.prototype.reduce " + "called on null or undefined"
            );
          }
          if (typeof callback !== "function") {
            throw new TypeError(callback + " is not a function");
          }

          // 1. Let O be ? ToObject(this value).
          var o = Object(this);

          // 2. Let len be ? ToLength(? Get(O, "length")).
          var len = o.length >>> 0;

          // Steps 3, 4, 5, 6, 7
          var k = 0;
          var value;

          if (arguments.length >= 2) {
            value = arguments[1];
          } else {
            while (k < len && !(k in o)) {
              k++;
            }

            // 3. If len is 0 and initialValue is not present,
            //    throw a TypeError exception.
            if (k >= len) {
              throw new TypeError(
                "Reduce of empty array " + "with no initial value"
              );
            }
            value = o[k++];
          }

          // 8. Repeat, while k < len
          while (k < len) {
            // a. Let Pk be ! ToString(k).
            // b. Let kPresent be ? HasProperty(O, Pk).
            // c. If kPresent is true, then
            //    i.  Let kValue be ? Get(O, Pk).
            //    ii. Let accumulator be ? Call(
            //          callbackfn, undefined,
            //          « accumulator, kValue, k, O »).
            if (k in o) {
              value = callback(value, o[k], k, o);
            }

            // d. Increase k by 1.
            k++;
          }

          // 9. Return accumulator.
          return value;
        },
      });
    }
  },
  /**下面几个方法是判定是否是乱码的--调用isCompatibleStr
   * @brief return true if the string is Compatible string ,otherwise return false;
   **/
  isCompatibleStr: function (str) {
    var _this = this;
    var flag = "";
    if (_this.isUndefinedOrNull(str)) return false;
    for (var i = 0; i < str.length; i++) {
      var tmp = str.charAt(i);
      flag += _this.isChineseChar(tmp) || _this.isLetterOrNumber(tmp) || _this.isCompatibleChar(tmp);
    }
    return flag;
  },
  /**
   *@brief:return true if the object is undefined or null, otherwise return false
   **/
  isUndefinedOrNull: function (str) {
    if (typeof str == "undefined") {
      return true; // it is undefined
    } else if (!str && str != 0) {
      return true; // it is null
    }
    return false;
  },
  /**
   * @brief return true if the char is chinese otherwise return false;
   **/
  isChineseChar: function (character) {
    var _this = this;
    var chineseRange = [
      [0x4e00, 0x9fff], // CJK Unified Ideographs
      [0x3400, 0x4dbf], // CJK Unified Ideographs Extension A
      [0x20000, 0x2a6df], // CJK Unified Ideographs Extension B
      [0x2a700, 0x2b73f], // CJK Unified Ideographs Extension C
      [0x2b740, 0x2b81f], // CJK Unified Ideographs Extension D
      [0x2b820, 0x2ceaf], // CJK Unified Ideographs Extension E
      [0xf900, 0xfaff], // CJK Compatibility Ideographs
      [0x3300, 0x33ff], // https://en.wikipedia.org/wiki/CJK_Compatibility
      [0xfe30, 0xfe4f], // https://en.wikipedia.org/wiki/CJK_Compatibility_Forms
      [0xf900, 0xfaff], // https://en.wikipedia.org/wiki/CJK_Compatibility_Ideographs
      [0x2f800, 0x2fa1f], // https://en.wikipedia.org/wiki/CJK_Compatibility_Ideographs_Supplement
    ];
    var charCode, flag;
    flag = false;
    charCode = character.charCodeAt(0);
    for (var j = 0; j < chineseRange.length; j++) {
      var r = chineseRange[j][0];
      var t = chineseRange[j][1];
      if (charCode >= r && charCode <= t) {
        flag = true;
        break;
      }
    }
    return flag ? character : "";
  },
  /**
   * @brief return true if the char is letter or number,otherwise return false;
   **/
  isLetterOrNumber: function (character) {
    var RegEx = /[A-Za-z0-9]/;
    return RegEx.test(character) ? character : "";
  },
  /**
   * @brief return true if the char is space or special character ,otherwise return false;
   **/
  isCompatibleChar: function (character) {
    var _this = this;
    var RegEx =
      /[\s\~\`\·\！\!@\#\￥\$%\……\^&\*\(\)\（\）\_\-\——\+\=\【\】\[\]\{\}\|\、<A>\\\</A>：\:\;\；\"\”\“\’\'\'\<\>\《\》\,\，\。\.\?\？\〇\/\「\」\〔\〕\﹝\﹞\『\』\／\–]/;
    return RegEx.test(character) ? character : "";
  },
  /**
   * 通过当前栏目id+所有子栏目id
   * @param {*} col_id 当前id
   * @returns Array
   */
  get28FullTreeId: function (col_id,exclude) {
    var _this = this;
    var node = _this.chnlData[col_id];
    var arr = [node.ID];
    var rev = function (node) {
      if (node && node.CHILDREN) {
        node.CHILDREN.split(";").forEach(function (e) {
          if(exclude.indexOf(e) == -1){
            arr.push(e);
            rev(_this.chnlData[e]);
          }
        });
      }
    };
    rev(node);
    return arr;
  },
  /**
   * 通过栏目id数组获取所有id
   * @param {*} arrIds
   * @returns String =>str1,str2
   */
  getChannelId: function (arrIds,exclude) {
    var _this = this;
    var arr = [];
    exclude = exclude || ""
    arrIds.forEach(function (id) {
      if(exclude.indexOf(id) == -1){
        if (_this.chnlData[id]) {
          var a = _this.get28FullTreeId(id,exclude);
          arr = arr.concat(a);
        }
      }
    });
    return arr.join(",");
  },
  getScrollToTop: function () {
    try {
      var scrollToTop = 0;
      var currentOffset = $scrollTop;
      if (currentOffset && currentOffset != fixOffsetDefault) {
        scrollToTop = currentOffset > fixOffsetDefault ? fixOffsetDefault : 0;
      }
      return scrollToTop;
    } catch (error) {}
  },
  animateScroll: function (num) {
    try {
      var _this = this;
      var _scrollToTop = typeof num == "number" ? num : _this.getScrollToTop();
      if (_scrollToTop == 0) {
        $scrollTop = 0;
        fixedStaus = 2;
        _this.moveTopFun(0);
      } else {
        var timer = setTimeout(function () {
          _this.moveTopFun(_scrollToTop + 10);
          clearTimeout(timer);
        }, 600);
      }
    } catch (error) {}
  },
  moveTopFun: function (num) {
    $("html,body").animate(
      {
        scrollTop: num,
      },
      100
    );
  },
  /**
   * 改变url参数 不刷新界面
   * @param {*} keyword decodeURIComponent之后的str
   */
  changeBrowserUrl: function (keyword, maxlength) {
    if (maxlength && keyword.length > maxlength) {
      keyword = keyword.slice(0, maxlength);
    }
    var url = window.location;
    var pathName = url.pathname;
    var locationSearch = url.search;
    var searchArr = locationSearch.substring(1).split("?");
    searchArr[0] = "webswd=" + keyword;
    var searchStr = "?" + searchArr.join("&");
    var newUrl = url.origin + pathName + searchStr;
    history.replaceState("", "", newUrl);
    // history.pushState('', '', newUrl)
    return keyword;
  },

  //gio全文检索点击满意度（不满意）后->卷调研按钮点击量统计
  clickSurveyBtnNew: function (lt768Falg) {
    try {
      gdp("track", "sseSearchSidebarClick", {
        sseSearchSideBtn_var1: "2",
      });
    } catch (error) {}
    var url = "https://survey.sse.com.cn/q/DqGjox";
    window.open(url);
  },
  /**
   * 节流是否通过
   * @param {*} currentTime 上一次点击的时间戳
   * @param {*} time 间隔时间
   * @returns
   */
  throttlePass: function (currentTime, time) {
    if (currentTime && new Date().getTime() - currentTime < time) {
      return false;
    } else {
      return true;
    }
  },
  /**
   * 获取随机整数
   * @param {*} len 字符长度
   * @param {*} radix 扩大倍数
   * @returns
   */
  getUuid: function (len, radix) {
    var chars = "01234567891357924680",
      uuid = [],
      i;
    radix = radix || chars.length;
    if (len) {
      for (i = 0; i < len; i++) uuid[i] = chars[0 | (Math.random() * radix)];
    }
    return uuid.join("");
  },
  /**
   * 获取对象所有values
   * @param {*} obj 对象
   * @returns Array
   */
  getObjValues: function (obj) {
    if (obj == null) {
      throw new TypeError("Cannot convert undefined or null to object");
    }
    if (!isIE) {
      return Object.values(obj);
    } else {
      var res = [];
      for (var k in obj) {
        if (obj.hasOwnProperty(k)) {
          //需判断是否是本身的属性
          res.push(obj[k]);
        }
      }
      return res;
    }
  },
  /**
   *搜索关键词过滤
   */
  filtrationStr: function (keyword) {
    return keyword.replace(
      /[\,\{\}\，\"\"\、\~\`\;\—\…\/\$\@\=\>\<\!\&\%\^\￥\#\!\！\+\?\'\\]|javascript|prompt|alert|vbscript/g,
      ""
    );
  },
};

sseSearch.init();

//gio全文搜索公告文件点击量统计
var sseSearch2022_this = sseSearch;
function clickPdf(t) {
  try {
    gdp("track", "sseSeachAnnouncementClick", {
      sseCheckPdf_var: t.text(),
    });
  } catch (error) {}
  var paramObj = {
    id: t.attr("id"),
    documentId: t.attr("documentId"),
    title: t.text(),
  };
  // sseSearch2022_this.getSearchTitleClick(paramObj,sseSearch2022_this) // 暂时不上线
}
