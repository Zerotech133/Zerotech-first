﻿/**
 * 规则总览
 */
if ($("#js_RuleMapEharts").length > 0) {
  require(['echarts'], function (echarts) {
     var dom = document.getElementById('js_RuleMapEharts');
var myChart = echarts.init(dom, null, {
  renderer: 'canvas',
  useDirtyRect: false
});
var app = {};


var option;

myChart.showLoading();

const data = {
  name: '上交所业务规则导览',
  children: [
    {name: '章程',
     link: '/lawandrules/sselawsrules2025/article/',
    },
    {name: '股票',
     link: '/lawandrules/sselawsrules2025/stocks/review/firstepisode/',
        children: [
            {name: '发行上市审核',
             link: '/lawandrules/sselawsrules2025/stocks/review/firstepisode/',
                children: [
                    {name: '首发',
                     link: '/lawandrules/sselawsrules2025/stocks/review/firstepisode/',
                    },
                    {name: '再融资',
                     link: '/lawandrules/sselawsrules2025/stocks/review/refinancing/',
                    },
                    {name: '重组',
                    link: '/lawandrules/sselawsrules2025/stocks/review/recombination/',
                    },
                    {name: '转板',
                    link: '/lawandrules/sselawsrules2025/stocks/review/flap/',
                    },
                ]
            },
            {name: '发行承销',
             link: '/lawandrules/sselawsrules2025/stocks/issue/',},
            {name: '主板上市（挂牌）',
             link: '/lawandrules/sselawsrules2025/stocks/mainipo/',
            },
            {name: '科创板上市（挂牌）',
             link: '/lawandrules/sselawsrules2025/stocks/staripo/',
            },
            {name: '股票交易',
             link: '/lawandrules/sselawsrules2025/stocks/exchange/',
            },
            {name: '试点创新企业',
             link: '/lawandrules/sselawsrules2025/stocks/innovative/',
            },
            {name: '股权分置改革',
             link: '/lawandrules/sselawsrules2025/stocks/reform/',
            },
         ]
    },
    {name: '债券',
     link: '/lawandrules/sselawsrules2025/bond/review/',
        children: [
            {name: '发行上市审核',
             link: '/lawandrules/sselawsrules2025/bond/review/',
            },
            {name: '发行承销',
             link: '/lawandrules/sselawsrules2025/bond/issue/',
            },
            {name: '上市（挂牌）',
             link: '/lawandrules/sselawsrules2025/bond/listing/corporatebond/',
                children: [
                    {name: '公司债券上市（挂牌）',
                     link: '/lawandrules/sselawsrules2025/bond/listing/corporatebond/',
                    },
                    {name: '资产支持证券上市（挂牌）',
                     link: '/lawandrules/sselawsrules2025/bond/listing/assets/',
                    },
                ]
            },
             {name: '债券交易',
              link: '/lawandrules/sselawsrules2025/bond/trading/currency/',
                children: [
                    {name: '债券交易通用',
                     link: '/lawandrules/sselawsrules2025/bond/trading/currency/',
                    },
                    {name: '国债预发行',
                     link: '/lawandrules/sselawsrules2025/bond/trading/tbondp/',
                    },
                    {name: '国债质押式三方回购',
                     link: '/lawandrules/sselawsrules2025/bond/trading/tripartyrepo/',
                    },
                    {name: '国债质押式协议回购',
                     link: '/lawandrules/sselawsrules2025/bond/trading/repurchase/',
                    },
                    {name: '国债买断式回购交易',
                     link: '/lawandrules/sselawsrules2025/bond/trading/outrightrepo/',
                    },
                    {name: '信用保护工具',
                     link: '/lawandrules/sselawsrules2025/bond/trading/cdx/',
                    },
                ]
            },          
            {name: '上市公司可转债',
             link: '/lawandrules/sselawsrules2025/bond/convertible/',               
            },
         ]
    },
    {name: '基金',
     link: '/lawandrules/sselawsrules2025/fund/listing/',
        children: [
            {name: '基金上市',
             link: '/lawandrules/sselawsrules2025/fund/listing/',
            },
            {name: '基金交易',
             link: '/lawandrules/sselawsrules2025/fund/trading/',
            },
        ]
    },
    {name: '公募REITs',
     link: '/lawandrules/sselawsrules2025/reits/',
    },
    {name: '期权',
     link: '/lawandrules/sselawsrules2025/option/',
    },
    {name: '交易通用',
     link: '/lawandrules/sselawsrules2025/trade/universal/',
        children: [
            {name: '通用类',
             link: '/lawandrules/sselawsrules2025/trade/universal/',
            },
            {name: '特定业务',
             link: '/lawandrules/sselawsrules2025/trade/specific/margin/',
                children: [
                    {name: '融资融券',
                     link: '/lawandrules/sselawsrules2025/trade/specific/margin/',
                    },
                    {name: '转融通',
                     link: '/lawandrules/sselawsrules2025/trade/specific/refinancing/',
                    },
                    {name: '质押式回购',
                     link: '/lawandrules/sselawsrules2025/trade/specific/repo/',
                    },
                    {name: '质押式报价回购',
                     link: '/lawandrules/sselawsrules2025/trade/specific/pricerepo/',
                    },
                    {name: '约定购回',
                     link: '/lawandrules/sselawsrules2025/trade/specific/promise/',
                    },
                    {name: '协议转让',
                     link: '/lawandrules/sselawsrules2025/trade/specific/xyzr/',
                    },
                    {name: '其他',
                     link: '/lawandrules/sselawsrules2025/trade/specific/others/',
                    },
                ]
            },          
         ]
    },
    {name: '跨境创新业务',
     link: '/lawandrules/sselawsrules2025/global/hkexsc/',
        children: [
            {name: '沪港通',
             link: '/lawandrules/sselawsrules2025/global/hkexsc/',
            },
            {name: '互联互通存托凭证',
             link: '/lawandrules/sselawsrules2025/global/slsc/',
            },
        ]
    },
    {name: '会员管理',
     link: '/lawandrules/sselawsrules2025/member/personnel/',
        children: [
            {name: '会员管理',
             link: '/lawandrules/sselawsrules2025/member/personnel/',
            },
            {name: '适当性管理',
             link: '/lawandrules/sselawsrules2025/member/adequacy/',
            },
        ]
    },
    {name: '纪律处分与复核',
     link: '/lawandrules/sselawsrules2025/disciplinary/',
     },
    {name: '交易收费',
     link: '/lawandrules/sselawsrules2025/charge/',
    },
    {name: '其他业务规则',
     link: '/lawandrules/sselawsrules2025/other/',
    },
    {name: '已废止业务规则',
     link: '/lawandrules/sselawsrules2025/repeal/announcement/',
        children: [
            {name: '业务规则废止公告',
             link: '/lawandrules/sselawsrules2025/repeal/announcement/',
            },
            {name: '已废止规则文本',
             link: '/lawandrules/sselawsrules2025/repeal/rules/',
            },
        ]
    },
  ]
};

myChart.hideLoading();

myChart.setOption(
  (option = {
    tooltip: {
      trigger: 'item',
      triggerOn: 'mousemove'
    },
    legend: {
      top: '2%',
      left: '3%',
      orient: 'vertical',
      data: [
        {
          name: 'tree1',
          icon: 'rectangle'
        }
      ],
      borderColor: '#c23531'
    },
    textStyle: {
          fontSize:'16px',
    },
    series: [
      {
        type: 'tree',

        // name: 'tree1',

        data: [data],

        top: '0%',
        left: '5%',
        bottom: '2%',
        right: '25%',
        symbolSize: 7,
        nodePadding:30,
        initialTreeDepth: -1,
        label: {
          position: 'left',
          padding: [0, 20],
          verticalAlign: 'middle',
          align: 'left',
          fontSize: 14,
          rich: {
            link: {
                color: '#1890ff',
                textDecoration: 'underline',
                padding: [0,5,0,0]
            }
          }
        },
        // 修改formatter和click事件获取
        // formatter: function(params) {
  //           // 显示节点名称和链接
  //           return params.name + '\n\n' + 
  //               (params.data.link ? '{link|🔗 链接}' : '');
  //       },
        leaves: {
          label: {
            position: 'left',
            verticalAlign: 'middle',
            align: 'left'
          }
        },

        emphasis: {
          focus: 'descendant'
        },

        expandAndCollapse: false,

        animationDuration: 550,
        animationDurationUpdate: 750
      }
    ]
  })
);



myChart.on('click', function(params) {
    if (params.data.link) {
        window.open(params.data.link); // 在新标签页打开链接
    }
});
if (option && typeof option === 'object') {
  myChart.setOption(option);
}

window.addEventListener('resize', myChart.resize);
  })
}
//规则总览end


//
if ($(".js_RuleMap").length > 0) {
// 确保 sseMenuObj 存在
window.sseMenuObj = window.sseMenuObj || {};

// 定义方法（不依赖条件）
sseMenuObj.initRuleMap = function() {
 // if ($(".js_RuleMap").length > 0) {
   //  sseMenuObj.initRuleMap = function () {
        if ($(".js_RuleMap").length === 0) return;

        // this.menu_type = '3';
        // this.siteObj = this.formatNode('0');
        // var ret = '',
        //     //lv1 = this.getNodeChild(this.siteObj);
        //     lv1 = this.getNodeChild(this.siteObj);
        // for (var i = 0, len = lv1.length; i < len; i++) {
        //     var currNode_1 = lv1[i],
        //         lv2 = this.getNodeChild(currNode_1);       
        //     ret += '<div class="sse_list_tit1 red_bottom_border"><h2><a href="' + currNode_1.href + '" target="' + currNode_1.target + '"><i class="sseicon-icon_more hidden-xs"></i></a><span>' + currNode_1.label + '</span></h2></div>';
            
        //     //如果有第二级菜单
        //     if (lv2.length > 0) {
        //         ret += '<div class="sse_sitemap_wrap"><ul class="sse_sitemap light_grey">';
        //         for (var j = 0, len2 = lv2.length; j < len2; j++) {
        //             var currNode_2 = lv2[j],
        //                 lv3 = this.getNodeChild(currNode_2);
        //             ret += '<li><em><a href="' + currNode_2.href + '" target="' + currNode_2.target + '">' + currNode_2.label + '</a></em>';
        //             //如果有第三级菜单
        //             if (lv3.length > 0) {
        //                 ret += '<p>';
        //                 for (var k = 0, len3 = lv3.length; k < len3; k++) {
        //                     var currNode_3 = lv3[k];
        //                     ret += '<a href="' + currNode_3.href + '" target="' + currNode_3.target + '">' + currNode_3.label + '</a>';
        //                 }
        //                 ret += '</p>';
        //             }
        //             ret += '</li>';
        //         }
        //         ret += '</ul></div>';
        //     }
        // }
        // return ret;
        // alert(ret);
        var menu_lv = 0;
        this.specialNodeObj = this.findSpecialNode('20643');
        function getNodeMenu(theNode, menu_lv) {
            var lv = sseMenuObj.getNodeChild(theNode);
            var shtml = '';
            var menulv = 'menu_lv_' + menu_lv;
            if (lv.length > 0) {
                var childMenu = '',
                    displayStyle = '';
                for (var k = 0, len = lv.length; k < len; k++) {
                    currNode = lv[k];
                    var theChild = getNodeMenu(currNode, menu_lv + 1);
                    childMenu += theChild.html;
                    // if (theChild.active == 'active') {
                    //     theNode.active = 'active';
                    // }
                }
                
                shtml += '<li class="' + menulv + ' ' + theNode.active + ' arrow"><a href="javascript:void(0);" class="ib_mid_wrap hasMenu ' + theNode.nodeStyle + ' ' + theNode.active + '"><div class="ib_mid_before"></div><span class="ib_mid">' + theNode.label + '</span><i class="glyphicon"></i></a>';
                
                // if (theNode.active == 'active') {
                //     displayStyle = ' style="display:block;"';
                // }
                shtml += '<ul' + displayStyle + '>' + childMenu + '</ul>';
            } else {
                if  ((theNode.code == '20644')||(theNode.code == '20645')){
                }
                else {
                  shtml += '<li class="' + menulv + ' ' + theNode.active + ' round"><a href="' + theNode.href + '" target="_blank" class="ib_mid_wrap ' + theNode.nodeStyle + ' "><div class="ib_mid_before"></div><span class="ib_mid">' + theNode.label + '</span></a>';
                }
            }
            shtml += '</li>';
            return {
                html: shtml,
                active: theNode.active
            };
        }
        this.menu_type = '2';
        var specialNodeObj = this.specialNodeObj;
        if (typeof (specialNodeObj) != 'object') {

            return '';
        }
        
        // var ret = '<li class="menu_title ib_mid_wrap"><div class="ib_mid_before"></div><span class="ib_mid">' + specialNodeObj.node.label + '</span></li>'; //专栏标题
        var ret = '';

        var lv2 = specialNodeObj.lv;
        //如果有第二级菜单
        for (var j = 0, len2 = lv2.length; j < len2; j++) {
            var currNode = lv2[j];
            var childMenu = getNodeMenu(currNode, 1);
            ret += childMenu.html;
        }
        return ret;
 //   };
  //}
};

// 初始化流程
$(document).ready(function() {
  // 1. 加载数据
  const menuHtml = sseMenuObj.initRuleMap();
  // 3. 插入到 DOM
  $(".js_RuleMap").html(menuHtml);
});

}