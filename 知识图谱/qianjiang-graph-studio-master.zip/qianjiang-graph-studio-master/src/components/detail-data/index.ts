export * from './DetailData'
